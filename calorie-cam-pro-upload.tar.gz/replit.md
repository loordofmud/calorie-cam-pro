# replit.md

## Overview

This is a full-stack web application called "Calorie Cam Pro" - an AI-powered nutrition analysis tool that allows users to take photos of food and drinks to get instant nutritional information. The application uses OpenAI's vision API to analyze food and beverage images and provide detailed nutritional breakdowns including calories, macronutrients, health scores, and personalized insights.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack TypeScript architecture with clear separation between frontend and backend:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **File Upload**: Multer for handling image uploads
- **External API**: OpenAI Vision API for food analysis

## Key Components

### Database Schema
- **Users Table**: Basic user authentication (id, username, password)
- **Food Analyses Table**: Stores food analysis results with user association
- **Nutrition Data**: Structured JSON schema for nutritional information including calories, macronutrients, health insights, and food identification

### API Endpoints
- `POST /api/analyze-food`: Main endpoint for food image analysis
  - Accepts multipart/form-data with image file
  - Processes image through OpenAI Vision API
  - Stores analysis results in database
  - Returns structured nutrition data

### Core Features
- **Image Upload**: Drag-and-drop interface with file validation
- **Food & Drink Analysis**: AI-powered nutritional analysis using OpenAI Vision for both food and beverages
- **Nutrition Display**: Comprehensive breakdown of calories, macros, and health metrics
- **Meal & Drink Categorization**: Support for breakfast, lunch, dinner, snacks, and drinks
- **Progressive Web App**: Full PWA capabilities with offline support
- **Mobile-First**: Responsive design optimized for mobile devices

## Data Flow

1. **Image Capture/Upload**: Users select or capture food/drink images through the camera interface
2. **Image Processing**: Images are converted to base64 and sent to the backend
3. **AI Analysis**: Backend processes images through OpenAI Vision API with structured prompts for food and beverages
4. **Data Storage**: Analysis results are stored in PostgreSQL with optional user association and meal/drink categorization
5. **Results Display**: Frontend receives structured nutrition data and displays interactive visualizations

## Recent Changes

### 2025-07-13: Added Capacitor for Native Android APK
- Integrated Capacitor to create traditional Android APK files
- Configured Android project with proper permissions for camera and storage
- Added build scripts and comprehensive APK build documentation
- Set up app signing and release configuration for distribution
- Created automated build process with build-apk.sh script
- Enabled native Android features while maintaining web app functionality

### 2025-07-13: Enhanced PWA for Android Installation
- Added comprehensive PWA manifest with proper Android app configuration
- Created Android installation guide component with step-by-step instructions
- Enhanced PWA install prompt with better UX and offline detection
- Added app icons and proper meta tags for Android home screen installation
- Created detailed installation documentation for Android users
- Improved service worker for better offline functionality

### 2025-07-13: Added LogMeal API Integration
- Integrated LogMeal API as the primary food analysis service with specialized food recognition capabilities
- Added comprehensive LogMeal API service with access token management and detailed nutrition extraction
- Updated analysis routes to prioritize LogMeal API over OpenAI when both are available
- Created API status component to display which analysis service is active
- Enhanced error handling for both LogMeal and OpenAI API responses
- Added health check endpoint to show API configuration status

### 2025-07-13: Added Drink Analysis Support
- Updated OpenAI Vision prompts to analyze beverages including sodas, juices, cocktails, coffee, etc.
- Added "Drink" category to meal selector with 🥤 icon
- Enhanced UI text to include "Food & Drink" throughout the application
- Updated food diary summary to display drinks category
- Improved analysis for liquid volume estimates, sugar content, caffeine, and alcohol content

### 2025-07-13: Added PostgreSQL Database Integration
- Replaced in-memory storage with PostgreSQL database using Neon
- Added database relations for users, food analyses, and food diary
- Updated storage interface to use Drizzle ORM with proper type safety
- Successfully migrated database schema with `npm run db:push`
- Maintained existing IStorage interface for seamless backend integration

## External Dependencies

### Core Dependencies
- **LogMeal API**: Primary food analysis service with specialized food recognition (requires API key)
- **OpenAI API**: Fallback vision-based food analysis (requires API key)
- **Neon Database**: PostgreSQL database provider (requires DATABASE_URL)
- **Tailwind CSS**: For styling and responsive design
- **Radix UI**: For accessible UI components

### Development Tools
- **Drizzle Kit**: Database migrations and schema management
- **ESBuild**: For production builds
- **Vite**: Development server and build tool

## Deployment Strategy

### Development
- Uses Vite dev server with hot module replacement
- Express server with middleware for API routes
- Environment variables for API keys and database connection

### Production
- Vite builds static frontend assets to `dist/public`
- ESBuild bundles server code to `dist/index.js`
- Single Node.js process serves both static assets and API
- Database migrations handled through Drizzle Kit

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `LOGMEAL_API_KEY`: LogMeal API key for specialized food analysis
- `OPENAI_API_KEY`: OpenAI API key for vision analysis (fallback)
- `NODE_ENV`: Environment setting (development/production)

The application is designed to be easily deployable on platforms like Replit, Vercel, or any Node.js hosting service with minimal configuration requirements.