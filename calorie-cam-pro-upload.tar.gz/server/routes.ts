import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { analyzeFoodImage } from "./services/openai-vision";
import { analyzeFoodWithLogMeal } from "./services/logmeal-api";
import { generateRecommendations, analyzeCurrentIntake } from "./services/nutrition-recommendations";
import { insertFoodAnalysisSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Analyze food image endpoint
  app.post("/api/analyze-food", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No image file provided" });
      }

      // Validate file type
      if (!req.file.mimetype.startsWith('image/')) {
        return res.status(400).json({ error: "Invalid file type. Please upload an image." });
      }

      // Validate file size (10MB limit)
      if (req.file.size > 10 * 1024 * 1024) {
        return res.status(400).json({ error: "File too large. Maximum size is 10MB." });
      }

      const base64Image = req.file.buffer.toString('base64');
      
      // Check which API is available and use it
      let analysisResults;
      
      if (process.env.LOGMEAL_API_KEY) {
        // Use LogMeal API if available (more specialized for food)
        analysisResults = await analyzeFoodWithLogMeal(base64Image);
      } else if (process.env.OPENAI_API_KEY) {
        // Fallback to OpenAI API
        analysisResults = await analyzeFoodImage(base64Image);
      } else {
        return res.status(500).json({ error: "No API key configured for food analysis" });
      }
      
      // Store analysis (optional user association)
      const userId = req.body.userId ? parseInt(req.body.userId) : null;
      const mealType = req.body.mealType || "snack";
      const notes = req.body.notes || null;
      
      const foodAnalysis = await storage.createFoodAnalysis({
        userId,
        imageBase64: base64Image,
        analysisResults,
        mealType,
        notes
      });

      // Update daily food diary totals if user is logged in
      if (userId) {
        const today = new Date().toISOString().split('T')[0];
        const currentDiary = await storage.getFoodDiary(userId, today);
        
        const newTotals = {
          totalCalories: (currentDiary?.totalCalories || 0) + analysisResults.calories,
          totalProtein: (currentDiary?.totalProtein || 0) + analysisResults.protein,
          totalCarbs: (currentDiary?.totalCarbs || 0) + analysisResults.carbs,
          totalFat: (currentDiary?.totalFat || 0) + analysisResults.fat,
        };

        await storage.updateFoodDiary(userId, today, newTotals);
      }

      res.json({
        id: foodAnalysis.id,
        analysisResults,
        mealType: foodAnalysis.mealType,
        notes: foodAnalysis.notes,
        createdAt: foodAnalysis.createdAt
      });
    } catch (error) {
      console.error("Food analysis error:", error);
      
      // Return more specific error messages
      if (error instanceof Error) {
        if (error.message.includes('API key') || error.message.includes('access token')) {
          return res.status(500).json({ error: "API key invalid or expired" });
        }
        if (error.message.includes('rate limit')) {
          return res.status(429).json({ error: "Analysis rate limit exceeded. Please try again later." });
        }
        if (error.message.includes('timeout')) {
          return res.status(504).json({ error: "Analysis timeout. Please try again with a smaller image." });
        }
        if (error.message.includes('LogMeal')) {
          return res.status(500).json({ error: "LogMeal API error. Please try again." });
        }
      }
      
      res.status(500).json({ 
        error: "Failed to analyze food image. Please try again.",
        details: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined
      });
    }
  });

  // Get food analysis by ID
  app.get("/api/food-analysis/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getFoodAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ error: "Food analysis not found" });
      }

      res.json(analysis);
    } catch (error) {
      console.error("Get food analysis error:", error);
      res.status(500).json({ error: "Failed to retrieve food analysis" });
    }
  });

  // Get user's food analysis history
  app.get("/api/user/:userId/food-analyses", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const analyses = await storage.getFoodAnalysesByUser(userId);
      
      res.json(analyses);
    } catch (error) {
      console.error("Get user food analyses error:", error);
      res.status(500).json({ error: "Failed to retrieve food analyses" });
    }
  });

  // Get food diary for a specific date
  app.get("/api/food-diary/:userId/:date", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const date = req.params.date;
      
      const diary = await storage.getFoodDiary(userId, date);
      const dailyAnalyses = await storage.getFoodAnalysesByDate(userId, date);
      
      res.json({
        diary: diary || {
          userId,
          date,
          targetCalories: 2000,
          totalCalories: 0,
          totalProtein: 0,
          totalCarbs: 0,
          totalFat: 0
        },
        meals: dailyAnalyses
      });
    } catch (error) {
      console.error("Get food diary error:", error);
      res.status(500).json({ error: "Failed to retrieve food diary" });
    }
  });

  // Update food diary targets
  app.put("/api/food-diary/:userId/:date", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const date = req.params.date;
      const { targetCalories } = req.body;
      
      const updatedDiary = await storage.updateFoodDiary(userId, date, {
        targetCalories: targetCalories || 2000
      });
      
      res.json(updatedDiary);
    } catch (error) {
      console.error("Update food diary error:", error);
      res.status(500).json({ error: "Failed to update food diary" });
    }
  });

  // Delete food analysis
  app.delete("/api/food-analysis/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getFoodAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ error: "Food analysis not found" });
      }

      // TODO: Implement delete functionality in storage
      res.json({ message: "Food analysis deleted successfully" });
    } catch (error) {
      console.error("Delete food analysis error:", error);
      res.status(500).json({ error: "Failed to delete food analysis" });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      openaiConfigured: !!process.env.OPENAI_API_KEY,
      logmealConfigured: !!process.env.LOGMEAL_API_KEY,
      primaryApi: process.env.LOGMEAL_API_KEY ? 'LogMeal' : (process.env.OPENAI_API_KEY ? 'OpenAI' : 'none')
    });
  });

  // Get food database
  app.get("/api/food-database", async (req, res) => {
    try {
      const recommendations = generateRecommendations({
        currentWeight: 70,
        targetWeight: 70,
        activityLevel: 'moderate'
      });
      
      res.json(recommendations.recommendedFoods);
    } catch (error) {
      console.error("Get food database error:", error);
      res.status(500).json({ error: "Failed to retrieve food database" });
    }
  });

  // Get nutrition recommendations
  app.post("/api/nutrition-recommendations", async (req, res) => {
    try {
      const { weightGoal, currentIntake } = req.body;
      
      if (!weightGoal || !currentIntake) {
        return res.status(400).json({ error: "Weight goal and current intake are required" });
      }
      
      const recommendations = generateRecommendations(weightGoal);
      res.json(recommendations);
    } catch (error) {
      console.error("Get nutrition recommendations error:", error);
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });

  // Analyze current intake
  app.post("/api/analyze-intake", async (req, res) => {
    try {
      const { userId, date, weightGoal } = req.body;
      
      if (!userId || !date || !weightGoal) {
        return res.status(400).json({ error: "User ID, date, and weight goal are required" });
      }
      
      const dailyAnalyses = await storage.getFoodAnalysesByDate(userId, date);
      const nutritionData = dailyAnalyses.map((analysis: any) => analysis.analysisResults).filter(Boolean);
      
      const intakeAnalysis = analyzeCurrentIntake(nutritionData as any[], weightGoal);
      res.json(intakeAnalysis);
    } catch (error) {
      console.error("Analyze intake error:", error);
      res.status(500).json({ error: "Failed to analyze current intake" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
