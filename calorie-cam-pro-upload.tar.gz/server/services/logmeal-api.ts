import { NutritionData } from "@shared/schema";

const LOGMEAL_API_URL = "https://api.logmeal.es";

if (!process.env.LOGMEAL_API_KEY) {
  console.error('LOGMEAL_API_KEY environment variable is not set');
}

export async function analyzeFoodWithLogMeal(base64Image: string): Promise<NutritionData> {
  try {
    // Step 1: Get access token
    const tokenResponse = await fetch(`${LOGMEAL_API_URL}/v2/token`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.LOGMEAL_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    if (!tokenResponse.ok) {
      throw new Error('Failed to get LogMeal access token');
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.token;

    // Step 2: Upload image for food recognition
    const imageBuffer = Buffer.from(base64Image, 'base64');
    const formData = new FormData();
    const blob = new Blob([imageBuffer], { type: 'image/jpeg' });
    formData.append('image', blob, 'food.jpg');

    const recognitionResponse = await fetch(`${LOGMEAL_API_URL}/v2/image/segmentation/complete`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`
      },
      body: formData
    });

    if (!recognitionResponse.ok) {
      throw new Error('Failed to analyze food with LogMeal');
    }

    const recognitionData = await recognitionResponse.json();
    
    // Step 3: Extract nutrition data from LogMeal response
    const nutritionData = await extractNutritionFromLogMeal(recognitionData, accessToken);
    
    return nutritionData;
  } catch (error) {
    console.error('LogMeal API error:', error);
    throw error;
  }
}

async function extractNutritionFromLogMeal(recognitionData: any, accessToken: string): Promise<NutritionData> {
  try {
    // Get detailed nutritional information
    const foodItems = recognitionData.segmentation_results || [];
    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;
    let totalFiber = 0;
    let totalSugar = 0;
    let totalSodium = 0;
    
    const detectedFoodItems = [];
    const insights = [];

    for (const item of foodItems) {
      if (item.recognition_results && item.recognition_results.length > 0) {
        const foodId = item.recognition_results[0].food_id;
        const confidence = item.recognition_results[0].prob;
        const foodName = item.recognition_results[0].food_name;

        // Get detailed nutrition info for this food item
        const nutritionResponse = await fetch(`${LOGMEAL_API_URL}/v2/nutrition/recipe/nutritionalInfo`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            food_id: foodId,
            nutritional_info: {
              calories: true,
              protein: true,
              carbs: true,
              fat: true,
              fiber: true,
              sugar: true,
              sodium: true
            }
          })
        });

        if (nutritionResponse.ok) {
          const nutritionInfo = await nutritionResponse.json();
          
          // Add to totals
          totalCalories += nutritionInfo.calories || 0;
          totalProtein += nutritionInfo.protein || 0;
          totalCarbs += nutritionInfo.carbs || 0;
          totalFat += nutritionInfo.fat || 0;
          totalFiber += nutritionInfo.fiber || 0;
          totalSugar += nutritionInfo.sugar || 0;
          totalSodium += nutritionInfo.sodium || 0;
        }

        detectedFoodItems.push({
          name: foodName,
          confidence: confidence,
          portion: "1 serving"
        });
      }
    }

    // Calculate health score based on nutritional balance
    const healthScore = calculateHealthScore(totalCalories, totalProtein, totalCarbs, totalFat, totalFiber, totalSugar, totalSodium);

    // Generate insights
    if (totalCalories > 500) {
      insights.push({
        type: "warning" as const,
        title: "High Calorie Content",
        description: `This meal contains ${Math.round(totalCalories)} calories, which is quite substantial.`,
        icon: "⚠️"
      });
    }

    if (totalProtein > 20) {
      insights.push({
        type: "positive" as const,
        title: "Good Protein Source",
        description: `Contains ${Math.round(totalProtein)}g of protein, supporting muscle health.`,
        icon: "💪"
      });
    }

    if (totalFiber > 5) {
      insights.push({
        type: "positive" as const,
        title: "High Fiber Content",
        description: `Rich in fiber (${Math.round(totalFiber)}g) which aids digestion.`,
        icon: "🌾"
      });
    }

    if (totalSugar > 15) {
      insights.push({
        type: "warning" as const,
        title: "High Sugar Content",
        description: `Contains ${Math.round(totalSugar)}g of sugar. Consider moderating intake.`,
        icon: "🍯"
      });
    }

    return {
      calories: Math.round(totalCalories),
      protein: Math.round(totalProtein),
      carbs: Math.round(totalCarbs),
      fat: Math.round(totalFat),
      fiber: Math.round(totalFiber),
      sugar: Math.round(totalSugar),
      sodium: Math.round(totalSodium),
      healthScore: healthScore,
      insights: insights,
      foodItems: detectedFoodItems
    };
  } catch (error) {
    console.error('Error extracting nutrition from LogMeal:', error);
    throw error;
  }
}

function calculateHealthScore(calories: number, protein: number, carbs: number, fat: number, fiber: number, sugar: number, sodium: number): number {
  let score = 70; // Base score
  
  // Adjust based on macronutrient balance
  const proteinRatio = protein * 4 / calories;
  const carbRatio = carbs * 4 / calories;
  const fatRatio = fat * 9 / calories;
  
  // Good protein ratio (15-25%)
  if (proteinRatio >= 0.15 && proteinRatio <= 0.25) score += 10;
  else if (proteinRatio < 0.10) score -= 10;
  
  // Good carb ratio (45-65%)
  if (carbRatio >= 0.45 && carbRatio <= 0.65) score += 5;
  else if (carbRatio > 0.70) score -= 10;
  
  // Good fat ratio (20-35%)
  if (fatRatio >= 0.20 && fatRatio <= 0.35) score += 5;
  else if (fatRatio > 0.40) score -= 10;
  
  // Fiber bonus
  if (fiber > 5) score += 10;
  if (fiber > 10) score += 5;
  
  // Sugar penalty
  if (sugar > 20) score -= 10;
  if (sugar > 30) score -= 10;
  
  // Sodium penalty
  if (sodium > 1000) score -= 10;
  if (sodium > 2000) score -= 10;
  
  return Math.max(0, Math.min(100, score));
}