import OpenAI from "openai";
import { NutritionData } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

if (!process.env.OPENAI_API_KEY) {
  console.error('OPENAI_API_KEY environment variable is not set');
}

export async function analyzeFoodImage(base64Image: string): Promise<NutritionData> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a professional nutritionist and food/beverage analysis expert. Analyze the food or drink image and provide comprehensive nutritional information in JSON format. Include:
          - Accurate calorie count
          - Macronutrients (protein, carbs, fat in grams)
          - Micronutrients (fiber, sugar, sodium in mg/g)
          - Health score (1-10 scale)
          - Detailed health insights with actionable advice
          - Food/drink items identified with confidence levels
          
          For beverages, focus on:
          - Liquid volume estimates
          - Sugar content (especially for sodas, juices, cocktails)
          - Alcohol content if applicable
          - Caffeine content if applicable
          - Artificial sweeteners if present
          
          Respond with JSON in this exact format:
          {
            "calories": number,
            "protein": number,
            "carbs": number,
            "fat": number,
            "fiber": number,
            "sugar": number,
            "sodium": number,
            "healthScore": number,
            "insights": [
              {
                "type": "positive|warning|info",
                "title": "string",
                "description": "string",
                "icon": "emoji"
              }
            ],
            "foodItems": [
              {
                "name": "string",
                "confidence": number,
                "portion": "string"
              }
            ]
          }`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Please analyze this food or drink image and provide detailed nutritional information. Be as accurate as possible with portion sizes and nutritional values. If it's a beverage, estimate the volume and focus on sugar, caffeine, and alcohol content where applicable."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Validate and sanitize the response
    return {
      calories: Math.max(0, result.calories || 0),
      protein: Math.max(0, result.protein || 0),
      carbs: Math.max(0, result.carbs || 0),
      fat: Math.max(0, result.fat || 0),
      fiber: Math.max(0, result.fiber || 0),
      sugar: Math.max(0, result.sugar || 0),
      sodium: Math.max(0, result.sodium || 0),
      healthScore: Math.max(1, Math.min(10, result.healthScore || 5)),
      insights: result.insights || [],
      foodItems: result.foodItems || []
    };
  } catch (error) {
    console.error("OpenAI Vision API error:", error);
    throw new Error("Failed to analyze food image: " + (error as Error).message);
  }
}
