import { NutritionData } from "@shared/schema";

export interface WeightGoal {
  currentWeight: number;
  targetWeight: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active';
  targetDate?: string;
}

export interface FoodRecommendation {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  portion: string;
  benefits: string[];
  category: 'protein' | 'carbs' | 'vegetables' | 'fruits' | 'dairy' | 'fats' | 'snacks';
  healthScore: number;
  icon: string;
}

export interface NutritionRecommendations {
  dailyCalories: number;
  dailyProtein: number;
  dailyCarbs: number;
  dailyFat: number;
  recommendedFoods: FoodRecommendation[];
  mealPlan: {
    breakfast: FoodRecommendation[];
    lunch: FoodRecommendation[];
    dinner: FoodRecommendation[];
    snacks: FoodRecommendation[];
  };
  tips: string[];
}

// Food database with nutritional information
const FOOD_DATABASE: FoodRecommendation[] = [
  // Proteins
  {
    name: "Grilled Chicken Breast",
    calories: 165,
    protein: 31,
    carbs: 0,
    fat: 3.6,
    fiber: 0,
    sugar: 0,
    sodium: 74,
    portion: "100g",
    benefits: ["High protein", "Low fat", "Muscle building"],
    category: "protein",
    healthScore: 9,
    icon: "🍗"
  },
  {
    name: "Lean Ground Turkey",
    calories: 189,
    protein: 27,
    carbs: 0,
    fat: 8,
    fiber: 0,
    sugar: 0,
    sodium: 98,
    portion: "100g",
    benefits: ["High protein", "Lower fat than beef", "B vitamins"],
    category: "protein",
    healthScore: 8,
    icon: "🦃"
  },
  {
    name: "Eggs",
    calories: 155,
    protein: 13,
    carbs: 1.1,
    fat: 11,
    fiber: 0,
    sugar: 1.1,
    sodium: 124,
    portion: "2 large eggs",
    benefits: ["Complete protein", "Choline", "Vitamin D"],
    category: "protein",
    healthScore: 9,
    icon: "🥚"
  },
  {
    name: "Lean Beef",
    calories: 250,
    protein: 26,
    carbs: 0,
    fat: 15,
    fiber: 0,
    sugar: 0,
    sodium: 72,
    portion: "100g",
    benefits: ["High protein", "Iron", "Zinc"],
    category: "protein",
    healthScore: 7,
    icon: "🥩"
  },
  {
    name: "Tuna",
    calories: 132,
    protein: 28,
    carbs: 0,
    fat: 1.3,
    fiber: 0,
    sugar: 0,
    sodium: 47,
    portion: "100g",
    benefits: ["Very high protein", "Omega-3", "Low calories"],
    category: "protein",
    healthScore: 9,
    icon: "🐟"
  },
  {
    name: "Cottage Cheese",
    calories: 98,
    protein: 11,
    carbs: 3.4,
    fat: 4.3,
    fiber: 0,
    sugar: 2.7,
    sodium: 364,
    portion: "100g",
    benefits: ["Casein protein", "Calcium", "Low carbs"],
    category: "protein",
    healthScore: 8,
    icon: "🧀"
  },
  {
    name: "Lentils",
    calories: 116,
    protein: 9,
    carbs: 20,
    fat: 0.4,
    fiber: 8,
    sugar: 1.8,
    sodium: 2,
    portion: "100g cooked",
    benefits: ["Plant protein", "High fiber", "Folate"],
    category: "protein",
    healthScore: 9,
    icon: "🌱"
  },
  {
    name: "Black Beans",
    calories: 132,
    protein: 9,
    carbs: 23,
    fat: 0.5,
    fiber: 9,
    sugar: 0.3,
    sodium: 2,
    portion: "100g cooked",
    benefits: ["Plant protein", "High fiber", "Antioxidants"],
    category: "protein",
    healthScore: 8,
    icon: "🫘"
  },
  {
    name: "Salmon Fillet",
    calories: 208,
    protein: 22,
    carbs: 0,
    fat: 12,
    fiber: 0,
    sugar: 0,
    sodium: 59,
    portion: "100g",
    benefits: ["Omega-3 fatty acids", "High protein", "Heart healthy"],
    category: "protein",
    healthScore: 10,
    icon: "🐟"
  },
  {
    name: "Greek Yogurt",
    calories: 59,
    protein: 10,
    carbs: 3.6,
    fat: 0.4,
    fiber: 0,
    sugar: 3.6,
    sodium: 36,
    portion: "100g",
    benefits: ["Probiotics", "High protein", "Calcium"],
    category: "protein",
    healthScore: 8,
    icon: "🥛"
  },
  {
    name: "Tofu",
    calories: 76,
    protein: 8,
    carbs: 1.9,
    fat: 4.8,
    fiber: 0.3,
    sugar: 0.6,
    sodium: 7,
    portion: "100g",
    benefits: ["Plant protein", "Low calories", "Versatile"],
    category: "protein",
    healthScore: 8,
    icon: "🧈"
  },
  
  // Carbohydrates
  {
    name: "Brown Rice",
    calories: 111,
    protein: 2.6,
    carbs: 23,
    fat: 0.9,
    fiber: 1.8,
    sugar: 0.4,
    sodium: 5,
    portion: "100g cooked",
    benefits: ["Complex carbs", "Fiber", "B vitamins"],
    category: "carbs",
    healthScore: 7,
    icon: "🍚"
  },
  {
    name: "Quinoa",
    calories: 120,
    protein: 4.4,
    carbs: 22,
    fat: 1.9,
    fiber: 2.8,
    sugar: 0.9,
    sodium: 7,
    portion: "100g cooked",
    benefits: ["Complete protein", "High fiber", "Gluten-free"],
    category: "carbs",
    healthScore: 9,
    icon: "🌾"
  },
  {
    name: "Sweet Potato",
    calories: 86,
    protein: 1.6,
    carbs: 20,
    fat: 0.1,
    fiber: 3,
    sugar: 4.2,
    sodium: 7,
    portion: "100g",
    benefits: ["Beta-carotene", "Fiber", "Potassium"],
    category: "carbs",
    healthScore: 8,
    icon: "🍠"
  },
  {
    name: "Oatmeal",
    calories: 68,
    protein: 2.4,
    carbs: 12,
    fat: 1.4,
    fiber: 1.7,
    sugar: 0.3,
    sodium: 4,
    portion: "100g cooked",
    benefits: ["Beta-glucan", "Fiber", "Heart healthy"],
    category: "carbs",
    healthScore: 8,
    icon: "🥣"
  },
  {
    name: "Whole Wheat Bread",
    calories: 247,
    protein: 13,
    carbs: 41,
    fat: 4.2,
    fiber: 7,
    sugar: 5.9,
    sodium: 399,
    portion: "100g",
    benefits: ["Whole grains", "Fiber", "B vitamins"],
    category: "carbs",
    healthScore: 7,
    icon: "🍞"
  },
  {
    name: "Whole Wheat Pasta",
    calories: 124,
    protein: 5,
    carbs: 25,
    fat: 1.1,
    fiber: 3.2,
    sugar: 1.2,
    sodium: 3,
    portion: "100g cooked",
    benefits: ["Complex carbs", "Fiber", "Sustained energy"],
    category: "carbs",
    healthScore: 7,
    icon: "🍝"
  },
  {
    name: "Barley",
    calories: 123,
    protein: 2.3,
    carbs: 28,
    fat: 0.4,
    fiber: 3.8,
    sugar: 0.8,
    sodium: 3,
    portion: "100g cooked",
    benefits: ["Beta-glucan", "Fiber", "Minerals"],
    category: "carbs",
    healthScore: 8,
    icon: "🌾"
  },
  
  // Vegetables
  {
    name: "Spinach",
    calories: 23,
    protein: 2.9,
    carbs: 3.6,
    fat: 0.4,
    fiber: 2.2,
    sugar: 0.4,
    sodium: 79,
    portion: "100g",
    benefits: ["Iron", "Folate", "Vitamin K"],
    category: "vegetables",
    healthScore: 10,
    icon: "🥬"
  },
  {
    name: "Broccoli",
    calories: 34,
    protein: 2.8,
    carbs: 7,
    fat: 0.4,
    fiber: 2.6,
    sugar: 1.5,
    sodium: 33,
    portion: "100g",
    benefits: ["Vitamin C", "Fiber", "Antioxidants"],
    category: "vegetables",
    healthScore: 9,
    icon: "🥦"
  },
  {
    name: "Bell Peppers",
    calories: 31,
    protein: 1,
    carbs: 7,
    fat: 0.3,
    fiber: 2.5,
    sugar: 4.2,
    sodium: 4,
    portion: "100g",
    benefits: ["Vitamin C", "Colorful antioxidants", "Low calories"],
    category: "vegetables",
    healthScore: 8,
    icon: "🫑"
  },
  {
    name: "Kale",
    calories: 35,
    protein: 2.9,
    carbs: 4.4,
    fat: 1.5,
    fiber: 4.1,
    sugar: 0.8,
    sodium: 53,
    portion: "100g",
    benefits: ["Vitamin K", "Antioxidants", "Calcium"],
    category: "vegetables",
    healthScore: 10,
    icon: "🥬"
  },
  {
    name: "Carrots",
    calories: 41,
    protein: 0.9,
    carbs: 10,
    fat: 0.2,
    fiber: 2.8,
    sugar: 4.7,
    sodium: 69,
    portion: "100g",
    benefits: ["Beta-carotene", "Vitamin A", "Fiber"],
    category: "vegetables",
    healthScore: 8,
    icon: "🥕"
  },
  {
    name: "Cauliflower",
    calories: 25,
    protein: 1.9,
    carbs: 5,
    fat: 0.3,
    fiber: 2,
    sugar: 1.9,
    sodium: 30,
    portion: "100g",
    benefits: ["Vitamin C", "Low carbs", "Versatile"],
    category: "vegetables",
    healthScore: 8,
    icon: "🥦"
  },
  {
    name: "Zucchini",
    calories: 17,
    protein: 1.2,
    carbs: 3.1,
    fat: 0.3,
    fiber: 1,
    sugar: 2.5,
    sodium: 8,
    portion: "100g",
    benefits: ["Low calories", "Hydrating", "Versatile"],
    category: "vegetables",
    healthScore: 7,
    icon: "🥒"
  },
  {
    name: "Asparagus",
    calories: 20,
    protein: 2.2,
    carbs: 3.9,
    fat: 0.1,
    fiber: 2.1,
    sugar: 1.9,
    sodium: 2,
    portion: "100g",
    benefits: ["Folate", "Vitamin K", "Antioxidants"],
    category: "vegetables",
    healthScore: 9,
    icon: "🫛"
  },
  {
    name: "Brussels Sprouts",
    calories: 43,
    protein: 3.4,
    carbs: 9,
    fat: 0.3,
    fiber: 3.8,
    sugar: 2.2,
    sodium: 25,
    portion: "100g",
    benefits: ["Vitamin C", "Vitamin K", "Fiber"],
    category: "vegetables",
    healthScore: 9,
    icon: "🥬"
  },
  
  // Fruits
  {
    name: "Blueberries",
    calories: 57,
    protein: 0.7,
    carbs: 14,
    fat: 0.3,
    fiber: 2.4,
    sugar: 10,
    sodium: 1,
    portion: "100g",
    benefits: ["Antioxidants", "Fiber", "Vitamin C"],
    category: "fruits",
    healthScore: 9,
    icon: "🫐"
  },
  {
    name: "Apple",
    calories: 52,
    protein: 0.3,
    carbs: 14,
    fat: 0.2,
    fiber: 2.4,
    sugar: 10,
    sodium: 1,
    portion: "100g",
    benefits: ["Fiber", "Vitamin C", "Pectin"],
    category: "fruits",
    healthScore: 8,
    icon: "🍎"
  },
  {
    name: "Banana",
    calories: 89,
    protein: 1.1,
    carbs: 23,
    fat: 0.3,
    fiber: 2.6,
    sugar: 12,
    sodium: 1,
    portion: "100g",
    benefits: ["Potassium", "Vitamin B6", "Natural sugars"],
    category: "fruits",
    healthScore: 7,
    icon: "🍌"
  },
  {
    name: "Strawberries",
    calories: 32,
    protein: 0.7,
    carbs: 7.7,
    fat: 0.3,
    fiber: 2,
    sugar: 4.9,
    sodium: 1,
    portion: "100g",
    benefits: ["Vitamin C", "Antioxidants", "Low calories"],
    category: "fruits",
    healthScore: 9,
    icon: "🍓"
  },
  {
    name: "Orange",
    calories: 47,
    protein: 0.9,
    carbs: 12,
    fat: 0.1,
    fiber: 2.4,
    sugar: 9.4,
    sodium: 0,
    portion: "100g",
    benefits: ["Vitamin C", "Folate", "Fiber"],
    category: "fruits",
    healthScore: 8,
    icon: "🍊"
  },
  {
    name: "Grapes",
    calories: 62,
    protein: 0.6,
    carbs: 16,
    fat: 0.2,
    fiber: 0.9,
    sugar: 16,
    sodium: 3,
    portion: "100g",
    benefits: ["Resveratrol", "Antioxidants", "Natural sugars"],
    category: "fruits",
    healthScore: 7,
    icon: "🍇"
  },
  {
    name: "Pineapple",
    calories: 50,
    protein: 0.5,
    carbs: 13,
    fat: 0.1,
    fiber: 1.4,
    sugar: 10,
    sodium: 1,
    portion: "100g",
    benefits: ["Bromelain", "Vitamin C", "Digestive enzymes"],
    category: "fruits",
    healthScore: 7,
    icon: "🍍"
  },
  {
    name: "Mango",
    calories: 60,
    protein: 0.8,
    carbs: 15,
    fat: 0.4,
    fiber: 1.6,
    sugar: 14,
    sodium: 1,
    portion: "100g",
    benefits: ["Vitamin A", "Vitamin C", "Antioxidants"],
    category: "fruits",
    healthScore: 8,
    icon: "🥭"
  },
  {
    name: "Kiwi",
    calories: 61,
    protein: 1.1,
    carbs: 15,
    fat: 0.5,
    fiber: 3,
    sugar: 9,
    sodium: 3,
    portion: "100g",
    benefits: ["Vitamin C", "Fiber", "Digestive health"],
    category: "fruits",
    healthScore: 8,
    icon: "🥝"
  },
  
  // Healthy Fats
  {
    name: "Avocado",
    calories: 160,
    protein: 2,
    carbs: 9,
    fat: 15,
    fiber: 7,
    sugar: 0.7,
    sodium: 7,
    portion: "100g",
    benefits: ["Healthy fats", "Fiber", "Potassium"],
    category: "fats",
    healthScore: 9,
    icon: "🥑"
  },
  {
    name: "Almonds",
    calories: 579,
    protein: 21,
    carbs: 22,
    fat: 50,
    fiber: 12,
    sugar: 4,
    sodium: 1,
    portion: "100g",
    benefits: ["Vitamin E", "Healthy fats", "Protein"],
    category: "fats",
    healthScore: 8,
    icon: "🌰"
  },
  {
    name: "Walnuts",
    calories: 654,
    protein: 15,
    carbs: 14,
    fat: 65,
    fiber: 7,
    sugar: 2.6,
    sodium: 2,
    portion: "100g",
    benefits: ["Omega-3", "Brain health", "Antioxidants"],
    category: "fats",
    healthScore: 9,
    icon: "🥜"
  },
  {
    name: "Olive Oil",
    calories: 884,
    protein: 0,
    carbs: 0,
    fat: 100,
    fiber: 0,
    sugar: 0,
    sodium: 2,
    portion: "100ml",
    benefits: ["Monounsaturated fats", "Vitamin E", "Anti-inflammatory"],
    category: "fats",
    healthScore: 8,
    icon: "🫒"
  },
  {
    name: "Chia Seeds",
    calories: 486,
    protein: 17,
    carbs: 42,
    fat: 31,
    fiber: 34,
    sugar: 0,
    sodium: 16,
    portion: "100g",
    benefits: ["Omega-3", "Fiber", "Protein"],
    category: "fats",
    healthScore: 9,
    icon: "🌱"
  },
  {
    name: "Flaxseeds",
    calories: 534,
    protein: 18,
    carbs: 29,
    fat: 42,
    fiber: 27,
    sugar: 1.6,
    sodium: 30,
    portion: "100g",
    benefits: ["Omega-3", "Lignans", "Fiber"],
    category: "fats",
    healthScore: 9,
    icon: "🌱"
  },
  
  // Healthy Snacks
  {
    name: "Greek Yogurt with Berries",
    calories: 100,
    protein: 12,
    carbs: 12,
    fat: 1,
    fiber: 2,
    sugar: 10,
    sodium: 40,
    portion: "150g",
    benefits: ["Probiotics", "Protein", "Antioxidants"],
    category: "snacks",
    healthScore: 9,
    icon: "🥛"
  },
  {
    name: "Hummus with Vegetables",
    calories: 120,
    protein: 5,
    carbs: 12,
    fat: 6,
    fiber: 4,
    sugar: 2,
    sodium: 200,
    portion: "50g hummus + 100g vegetables",
    benefits: ["Plant protein", "Fiber", "Healthy fats"],
    category: "snacks",
    healthScore: 8,
    icon: "🥕"
  },
  {
    name: "Mixed Nuts",
    calories: 607,
    protein: 20,
    carbs: 13,
    fat: 54,
    fiber: 8,
    sugar: 4,
    sodium: 16,
    portion: "100g",
    benefits: ["Healthy fats", "Protein", "Minerals"],
    category: "snacks",
    healthScore: 8,
    icon: "🥜"
  },
  {
    name: "Apple with Almond Butter",
    calories: 190,
    protein: 4,
    carbs: 24,
    fat: 11,
    fiber: 5,
    sugar: 19,
    sodium: 2,
    portion: "1 medium apple + 2 tbsp almond butter",
    benefits: ["Fiber", "Healthy fats", "Sustained energy"],
    category: "snacks",
    healthScore: 8,
    icon: "🍎"
  },
  {
    name: "Dark Chocolate",
    calories: 546,
    protein: 5,
    carbs: 46,
    fat: 31,
    fiber: 11,
    sugar: 24,
    sodium: 20,
    portion: "100g",
    benefits: ["Antioxidants", "Flavonoids", "Magnesium"],
    category: "snacks",
    healthScore: 6,
    icon: "🍫"
  },
  {
    name: "Protein Smoothie",
    calories: 250,
    protein: 25,
    carbs: 30,
    fat: 5,
    fiber: 6,
    sugar: 20,
    sodium: 150,
    portion: "1 serving",
    benefits: ["High protein", "Vitamins", "Quick nutrition"],
    category: "snacks",
    healthScore: 8,
    icon: "🥤"
  },
  
  // Additional Dairy
  {
    name: "Low-fat Milk",
    calories: 42,
    protein: 3.4,
    carbs: 5,
    fat: 1,
    fiber: 0,
    sugar: 5,
    sodium: 44,
    portion: "100ml",
    benefits: ["Calcium", "Protein", "Vitamin D"],
    category: "dairy",
    healthScore: 7,
    icon: "🥛"
  },
  {
    name: "Mozzarella Cheese",
    calories: 280,
    protein: 28,
    carbs: 3,
    fat: 17,
    fiber: 0,
    sugar: 1,
    sodium: 627,
    portion: "100g",
    benefits: ["Calcium", "Protein", "Vitamin B12"],
    category: "dairy",
    healthScore: 6,
    icon: "🧀"
  }
];

export function calculateDailyNeeds(weightGoal: WeightGoal): { calories: number; protein: number; carbs: number; fat: number } {
  const { currentWeight, targetWeight, activityLevel } = weightGoal;
  
  // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor equation
  // Using average height and age for estimation
  const bmr = 10 * currentWeight + 6.25 * 170 - 5 * 30 + 5; // Male formula as default
  
  // Activity multipliers
  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    'very-active': 1.9
  };
  
  const tdee = bmr * activityMultipliers[activityLevel];
  
  // Adjust calories based on weight goal
  let targetCalories = tdee;
  if (targetWeight < currentWeight) {
    // Weight loss: reduce by 500 calories per day for 1 pound per week
    targetCalories = tdee - 500;
  } else if (targetWeight > currentWeight) {
    // Weight gain: increase by 300-500 calories per day
    targetCalories = tdee + 400;
  }
  
  // Ensure minimum calories
  targetCalories = Math.max(targetCalories, 1200);
  
  // Calculate macronutrient distribution
  const protein = Math.round((targetCalories * 0.25) / 4); // 25% protein
  const carbs = Math.round((targetCalories * 0.45) / 4); // 45% carbs
  const fat = Math.round((targetCalories * 0.30) / 9); // 30% fat
  
  return {
    calories: Math.round(targetCalories),
    protein,
    carbs,
    fat
  };
}

export function generateRecommendations(weightGoal: WeightGoal): NutritionRecommendations {
  const dailyNeeds = calculateDailyNeeds(weightGoal);
  const isWeightLoss = weightGoal.targetWeight < weightGoal.currentWeight;
  const isWeightGain = weightGoal.targetWeight > weightGoal.currentWeight;
  
  // Filter foods based on goal
  let recommendedFoods = FOOD_DATABASE;
  
  if (isWeightLoss) {
    // Prioritize low-calorie, high-protein, high-fiber foods
    recommendedFoods = FOOD_DATABASE
      .filter(food => food.healthScore >= 7)
      .sort((a, b) => {
        const aScore = (a.protein / a.calories) * 100 + (a.fiber / a.calories) * 50;
        const bScore = (b.protein / b.calories) * 100 + (b.fiber / b.calories) * 50;
        return bScore - aScore;
      });
  } else if (isWeightGain) {
    // Prioritize nutrient-dense, calorie-rich foods
    recommendedFoods = FOOD_DATABASE
      .filter(food => food.healthScore >= 6)
      .sort((a, b) => {
        const aScore = a.calories + a.protein * 2;
        const bScore = b.calories + b.protein * 2;
        return bScore - aScore;
      });
  }
  
  // Generate meal plan
  const mealPlan = {
    breakfast: recommendedFoods.filter(food => 
      ['protein', 'fruits', 'dairy'].includes(food.category)
    ).slice(0, 3),
    lunch: recommendedFoods.filter(food => 
      ['protein', 'vegetables', 'carbs'].includes(food.category)
    ).slice(0, 4),
    dinner: recommendedFoods.filter(food => 
      ['protein', 'vegetables', 'carbs'].includes(food.category)
    ).slice(0, 4),
    snacks: recommendedFoods.filter(food => 
      food.category === 'snacks' || food.category === 'fruits'
    ).slice(0, 3)
  };
  
  // Generate tips based on goal
  const tips = [];
  if (isWeightLoss) {
    tips.push(
      "Focus on high-protein foods to maintain muscle mass",
      "Include plenty of vegetables for fiber and nutrients",
      "Stay hydrated - drink water before meals",
      "Eat slowly and mindfully to recognize fullness",
      "Choose whole foods over processed alternatives"
    );
  } else if (isWeightGain) {
    tips.push(
      "Eat frequent, nutrient-dense meals throughout the day",
      "Include healthy fats like avocado and nuts",
      "Focus on complex carbohydrates for sustained energy",
      "Add protein to every meal and snack",
      "Consider timing meals around workouts"
    );
  } else {
    tips.push(
      "Maintain a balanced diet with all food groups",
      "Focus on whole, minimally processed foods",
      "Stay consistent with meal timing",
      "Include a variety of colorful fruits and vegetables",
      "Listen to your body's hunger and fullness cues"
    );
  }
  
  return {
    dailyCalories: dailyNeeds.calories,
    dailyProtein: dailyNeeds.protein,
    dailyCarbs: dailyNeeds.carbs,
    dailyFat: dailyNeeds.fat,
    recommendedFoods: recommendedFoods.slice(0, 12),
    mealPlan,
    tips
  };
}

export function analyzeCurrentIntake(analysisResults: NutritionData[], weightGoal: WeightGoal): {
  analysis: string;
  suggestions: string[];
  missingNutrients: string[];
} {
  const dailyNeeds = calculateDailyNeeds(weightGoal);
  
  // Sum up today's intake
  const totalCalories = analysisResults.reduce((sum, result) => sum + result.calories, 0);
  const totalProtein = analysisResults.reduce((sum, result) => sum + result.protein, 0);
  const totalCarbs = analysisResults.reduce((sum, result) => sum + result.carbs, 0);
  const totalFat = analysisResults.reduce((sum, result) => sum + result.fat, 0);
  const totalFiber = analysisResults.reduce((sum, result) => sum + result.fiber, 0);
  
  const suggestions = [];
  const missingNutrients = [];
  
  // Analyze macronutrients
  if (totalCalories < dailyNeeds.calories * 0.8) {
    suggestions.push("You're under your calorie goal. Consider adding a healthy snack.");
  } else if (totalCalories > dailyNeeds.calories * 1.2) {
    suggestions.push("You're over your calorie goal. Focus on portion control.");
  }
  
  if (totalProtein < dailyNeeds.protein * 0.8) {
    suggestions.push("Add more protein sources like chicken, fish, or legumes.");
    missingNutrients.push("Protein");
  }
  
  if (totalFiber < 25) {
    suggestions.push("Include more fiber-rich foods like vegetables and whole grains.");
    missingNutrients.push("Fiber");
  }
  
  const analysis = `Today's intake: ${totalCalories} calories, ${totalProtein}g protein, ${totalCarbs}g carbs, ${totalFat}g fat. Target: ${dailyNeeds.calories} calories, ${dailyNeeds.protein}g protein.`;
  
  return {
    analysis,
    suggestions,
    missingNutrients
  };
}