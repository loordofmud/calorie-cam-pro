import { users, foodAnalyses, foodDiary, type User, type InsertUser, type FoodAnalysis, type InsertFoodAnalysis, type FoodDiary, type InsertFoodDiary } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createFoodAnalysis(analysis: InsertFoodAnalysis): Promise<FoodAnalysis>;
  getFoodAnalysesByUser(userId: number): Promise<FoodAnalysis[]>;
  getFoodAnalysis(id: number): Promise<FoodAnalysis | undefined>;
  getFoodAnalysesByDate(userId: number, date: string): Promise<FoodAnalysis[]>;
  createFoodDiary(diary: InsertFoodDiary): Promise<FoodDiary>;
  getFoodDiary(userId: number, date: string): Promise<FoodDiary | undefined>;
  updateFoodDiary(userId: number, date: string, updates: Partial<FoodDiary>): Promise<FoodDiary>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createFoodAnalysis(insertAnalysis: InsertFoodAnalysis): Promise<FoodAnalysis> {
    const [analysis] = await db
      .insert(foodAnalyses)
      .values(insertAnalysis)
      .returning();
    return analysis;
  }

  async getFoodAnalysesByUser(userId: number): Promise<FoodAnalysis[]> {
    return await db
      .select()
      .from(foodAnalyses)
      .where(eq(foodAnalyses.userId, userId));
  }

  async getFoodAnalysis(id: number): Promise<FoodAnalysis | undefined> {
    const [analysis] = await db
      .select()
      .from(foodAnalyses)
      .where(eq(foodAnalyses.id, id));
    return analysis || undefined;
  }

  async getFoodAnalysesByDate(userId: number, date: string): Promise<FoodAnalysis[]> {
    // Use SQL date function to compare only the date part
    const results = await db
      .select()
      .from(foodAnalyses)
      .where(eq(foodAnalyses.userId, userId));
    
    // Filter by date on the JavaScript side for better compatibility
    return results.filter(analysis => 
      analysis.createdAt && 
      analysis.createdAt.toISOString().split('T')[0] === date
    );
  }

  async createFoodDiary(insertDiary: InsertFoodDiary): Promise<FoodDiary> {
    const [diary] = await db
      .insert(foodDiary)
      .values(insertDiary)
      .returning();
    return diary;
  }

  async getFoodDiary(userId: number, date: string): Promise<FoodDiary | undefined> {
    const [diary] = await db
      .select()
      .from(foodDiary)
      .where(
        and(
          eq(foodDiary.userId, userId),
          eq(foodDiary.date, date)
        )
      );
    return diary || undefined;
  }

  async updateFoodDiary(userId: number, date: string, updates: Partial<FoodDiary>): Promise<FoodDiary> {
    // First try to update existing diary
    const existingDiary = await this.getFoodDiary(userId, date);
    
    if (existingDiary) {
      const [updatedDiary] = await db
        .update(foodDiary)
        .set(updates)
        .where(
          and(
            eq(foodDiary.userId, userId),
            eq(foodDiary.date, date)
          )
        )
        .returning();
      return updatedDiary;
    }

    // Create new diary if it doesn't exist
    const newDiary: InsertFoodDiary = {
      userId,
      date,
      targetCalories: 2000,
      totalCalories: 0,
      totalProtein: 0,
      totalCarbs: 0,
      totalFat: 0,
      ...updates
    };
    
    return await this.createFoodDiary(newDiary);
  }
}

export const storage = new DatabaseStorage();
