import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const foodAnalyses = pgTable("food_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  imageBase64: text("image_base64").notNull(),
  analysisResults: jsonb("analysis_results").notNull(),
  mealType: text("meal_type").notNull().default("snack"), // breakfast, lunch, dinner, snack
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const foodDiary = pgTable("food_diary", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  date: text("date").notNull(), // YYYY-MM-DD format
  targetCalories: integer("target_calories").default(2000),
  totalCalories: integer("total_calories").default(0),
  totalProtein: integer("total_protein").default(0),
  totalCarbs: integer("total_carbs").default(0),
  totalFat: integer("total_fat").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  foodAnalyses: many(foodAnalyses),
  foodDiary: many(foodDiary),
}));

export const foodAnalysesRelations = relations(foodAnalyses, ({ one }) => ({
  user: one(users, {
    fields: [foodAnalyses.userId],
    references: [users.id],
  }),
}));

export const foodDiaryRelations = relations(foodDiary, ({ one }) => ({
  user: one(users, {
    fields: [foodDiary.userId],
    references: [users.id],
  }),
}));

export const nutritionData = z.object({
  calories: z.number(),
  protein: z.number(),
  carbs: z.number(),
  fat: z.number(),
  fiber: z.number(),
  sugar: z.number(),
  sodium: z.number(),
  healthScore: z.number(),
  insights: z.array(z.object({
    type: z.enum(["positive", "warning", "info"]),
    title: z.string(),
    description: z.string(),
    icon: z.string()
  })),
  foodItems: z.array(z.object({
    name: z.string(),
    confidence: z.number(),
    portion: z.string()
  }))
});

export const insertFoodAnalysisSchema = createInsertSchema(foodAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertFoodDiarySchema = createInsertSchema(foodDiary).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertFoodAnalysis = z.infer<typeof insertFoodAnalysisSchema>;
export type FoodAnalysis = typeof foodAnalyses.$inferSelect;
export type InsertFoodDiary = z.infer<typeof insertFoodDiarySchema>;
export type FoodDiary = typeof foodDiary.$inferSelect;
export type NutritionData = z.infer<typeof nutritionData>;
