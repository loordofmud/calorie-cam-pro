import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Goals() {
  const [location, setLocation] = useLocation();
  const [weightGoal, setWeightGoal] = useState("70");
  const [currentWeight, setCurrentWeight] = useState("75");
  const [targetDate, setTargetDate] = useState("");
  const [activityLevel, setActivityLevel] = useState("moderate");
  const [calorieGoal, setCalorieGoal] = useState("2000");
  const [proteinGoal, setProteinGoal] = useState("120");
  const [carbsGoal, setCarbsGoal] = useState("250");
  const [fatGoal, setFatGoal] = useState("65");
  const { toast } = useToast();

  const handleSaveGoals = () => {
    toast({
      title: "Goals updated",
      description: "Your nutrition and fitness goals have been saved successfully."
    });
  };

  const calculateBMI = () => {
    const weight = parseFloat(currentWeight);
    const height = 1.75; // Default height in meters
    return weight / (height * height);
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { category: "Underweight", color: "text-blue-600" };
    if (bmi < 25) return { category: "Normal", color: "text-green-600" };
    if (bmi < 30) return { category: "Overweight", color: "text-yellow-600" };
    return { category: "Obese", color: "text-red-600" };
  };

  const bmi = calculateBMI();
  const bmiInfo = getBMICategory(bmi);
  const weightProgress = currentWeight && weightGoal ? 
    Math.max(0, 100 - (Math.abs(parseFloat(currentWeight) - parseFloat(weightGoal)) / parseFloat(weightGoal)) * 100) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-200/30 to-green-300/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-blue-200/20 to-emerald-200/20 rounded-full blur-3xl animate-float-delayed"></div>
      </div>

      {/* Header */}
      <header className="relative glass-morphism sticky top-0 z-40 border-b border-white/20">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                onClick={() => setLocation('/')}
                variant="ghost"
                size="sm"
                className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg hover:from-emerald-600 hover:to-emerald-700"
              >
                <span className="text-white text-xl">←</span>
              </Button>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
                  Goals & Targets
                </h1>
                <p className="text-xs text-slate-600 font-medium">Track your progress</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-4xl mx-auto px-4 py-6 pb-20">
        <div className="space-y-6">
          {/* Current Status */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>📊</span>
                <span>Current Status</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-white/50 rounded-xl">
                  <div className="text-2xl font-bold text-slate-900">{currentWeight}kg</div>
                  <div className="text-sm text-slate-600">Current Weight</div>
                </div>
                <div className="text-center p-4 bg-white/50 rounded-xl">
                  <div className={`text-2xl font-bold ${bmiInfo.color}`}>{bmi.toFixed(1)}</div>
                  <div className="text-sm text-slate-600">BMI - {bmiInfo.category}</div>
                </div>
                <div className="text-center p-4 bg-white/50 rounded-xl">
                  <div className="text-2xl font-bold text-emerald-600">{weightProgress.toFixed(0)}%</div>
                  <div className="text-sm text-slate-600">Goal Progress</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Weight Goals */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>⚖️</span>
                <span>Weight Goals</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="current-weight">Current Weight (kg)</Label>
                  <Input
                    id="current-weight"
                    type="number"
                    value={currentWeight}
                    onChange={(e) => setCurrentWeight(e.target.value)}
                    placeholder="75"
                  />
                </div>
                <div>
                  <Label htmlFor="target-weight">Target Weight (kg)</Label>
                  <Input
                    id="target-weight"
                    type="number"
                    value={weightGoal}
                    onChange={(e) => setWeightGoal(e.target.value)}
                    placeholder="70"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="target-date">Target Date</Label>
                <Input
                  id="target-date"
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                />
              </div>
              <div>
                <Label>Weight Progress</Label>
                <Progress value={weightProgress} className="h-3 mt-2" />
                <p className="text-sm text-slate-600 mt-1">
                  {Math.abs(parseFloat(currentWeight) - parseFloat(weightGoal)).toFixed(1)}kg to go
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Activity Level */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>🏃</span>
                <span>Activity Level</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div>
                <Label htmlFor="activity">Activity Level</Label>
                <Select value={activityLevel} onValueChange={setActivityLevel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary (little to no exercise)</SelectItem>
                    <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                    <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                    <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                    <SelectItem value="very-active">Very Active (2x/day, intense)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Nutrition Goals */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>🥗</span>
                <span>Daily Nutrition Goals</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="calorie-goal">Calories</Label>
                  <Input
                    id="calorie-goal"
                    type="number"
                    value={calorieGoal}
                    onChange={(e) => setCalorieGoal(e.target.value)}
                    placeholder="2000"
                  />
                </div>
                <div>
                  <Label htmlFor="protein-goal">Protein (g)</Label>
                  <Input
                    id="protein-goal"
                    type="number"
                    value={proteinGoal}
                    onChange={(e) => setProteinGoal(e.target.value)}
                    placeholder="120"
                  />
                </div>
                <div>
                  <Label htmlFor="carbs-goal">Carbs (g)</Label>
                  <Input
                    id="carbs-goal"
                    type="number"
                    value={carbsGoal}
                    onChange={(e) => setCarbsGoal(e.target.value)}
                    placeholder="250"
                  />
                </div>
                <div>
                  <Label htmlFor="fat-goal">Fat (g)</Label>
                  <Input
                    id="fat-goal"
                    type="number"
                    value={fatGoal}
                    onChange={(e) => setFatGoal(e.target.value)}
                    placeholder="65"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Goal Presets */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>🎯</span>
                <span>Quick Goal Presets</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  variant="outline"
                  className="p-4 h-auto flex flex-col items-center space-y-2"
                  onClick={() => {
                    setCalorieGoal("1800");
                    setProteinGoal("100");
                    setCarbsGoal("200");
                    setFatGoal("60");
                  }}
                >
                  <span className="text-2xl">📉</span>
                  <span className="font-semibold">Weight Loss</span>
                  <span className="text-sm text-slate-600">1800 cal/day</span>
                </Button>
                <Button
                  variant="outline"
                  className="p-4 h-auto flex flex-col items-center space-y-2"
                  onClick={() => {
                    setCalorieGoal("2000");
                    setProteinGoal("120");
                    setCarbsGoal("250");
                    setFatGoal("65");
                  }}
                >
                  <span className="text-2xl">⚖️</span>
                  <span className="font-semibold">Maintenance</span>
                  <span className="text-sm text-slate-600">2000 cal/day</span>
                </Button>
                <Button
                  variant="outline"
                  className="p-4 h-auto flex flex-col items-center space-y-2"
                  onClick={() => {
                    setCalorieGoal("2500");
                    setProteinGoal("150");
                    setCarbsGoal("320");
                    setFatGoal("80");
                  }}
                >
                  <span className="text-2xl">📈</span>
                  <span className="font-semibold">Muscle Gain</span>
                  <span className="text-sm text-slate-600">2500 cal/day</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <Button
            onClick={handleSaveGoals}
            className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white py-4 px-6 rounded-2xl font-semibold shadow-lg"
          >
            🎯 Save Goals
          </Button>
        </div>
      </main>
    </div>
  );
}