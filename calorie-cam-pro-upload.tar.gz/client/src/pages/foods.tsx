import { useState } from "react";
import { FoodBrowser } from "@/components/food-browser";
import { NutritionRecommendations } from "@/components/nutrition-recommendations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface WeightGoal {
  currentWeight: number;
  targetWeight: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active';
  targetDate?: string;
}

export default function Foods() {
  const [weightGoal, setWeightGoal] = useState<WeightGoal>({
    currentWeight: 70,
    targetWeight: 65,
    activityLevel: 'moderate'
  });
  const [showRecommendations, setShowRecommendations] = useState(false);

  const currentIntake = {
    calories: 1200,
    protein: 60,
    carbs: 150,
    fat: 40
  };

  const handleWeightGoalSubmit = () => {
    setShowRecommendations(true);
  };

  const handleAddFood = (food: any) => {
    // TODO: Implement adding food to meal plan
    console.log("Adding food to meal plan:", food);
  };

  const activityLevels = [
    { value: 'sedentary', label: 'Sedentary (little to no exercise)' },
    { value: 'light', label: 'Light (light exercise 1-3 days/week)' },
    { value: 'moderate', label: 'Moderate (moderate exercise 3-5 days/week)' },
    { value: 'active', label: 'Active (hard exercise 6-7 days/week)' },
    { value: 'very-active', label: 'Very Active (very hard exercise & physical job)' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-green-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">🍽️ Food Database & Recommendations</h1>
          <p className="text-slate-600">Discover nutritious foods and get personalized meal suggestions</p>
        </div>

        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="browse">Browse Foods</TabsTrigger>
            <TabsTrigger value="goals">Set Goals</TabsTrigger>
            <TabsTrigger value="recommendations">Get Recommendations</TabsTrigger>
          </TabsList>
          
          <TabsContent value="browse" className="space-y-6">
            <FoodBrowser onAddFood={handleAddFood} />
          </TabsContent>
          
          <TabsContent value="goals" className="space-y-6">
            <Card className="glass-morphism border-emerald-200/50 max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>🎯</span>
                  <span>Set Your Weight Goals</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="currentWeight">Current Weight (kg)</Label>
                    <Input
                      id="currentWeight"
                      type="number"
                      value={weightGoal.currentWeight}
                      onChange={(e) => setWeightGoal({
                        ...weightGoal,
                        currentWeight: parseFloat(e.target.value) || 0
                      })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="targetWeight">Target Weight (kg)</Label>
                    <Input
                      id="targetWeight"
                      type="number"
                      value={weightGoal.targetWeight}
                      onChange={(e) => setWeightGoal({
                        ...weightGoal,
                        targetWeight: parseFloat(e.target.value) || 0
                      })}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="activityLevel">Activity Level</Label>
                  <Select 
                    value={weightGoal.activityLevel} 
                    onValueChange={(value: any) => setWeightGoal({
                      ...weightGoal,
                      activityLevel: value
                    })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select activity level" />
                    </SelectTrigger>
                    <SelectContent>
                      {activityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="bg-slate-50 rounded-lg p-4">
                  <h3 className="font-semibold text-slate-900 mb-2">Goal Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="text-slate-600">Current</div>
                      <div className="font-semibold">{weightGoal.currentWeight} kg</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Target</div>
                      <div className="font-semibold">{weightGoal.targetWeight} kg</div>
                    </div>
                    <div>
                      <div className="text-slate-600">Change</div>
                      <div className={`font-semibold ${
                        weightGoal.targetWeight < weightGoal.currentWeight 
                          ? 'text-emerald-600' 
                          : weightGoal.targetWeight > weightGoal.currentWeight 
                            ? 'text-blue-600' 
                            : 'text-slate-600'
                      }`}>
                        {weightGoal.targetWeight < weightGoal.currentWeight 
                          ? `−${(weightGoal.currentWeight - weightGoal.targetWeight).toFixed(1)} kg` 
                          : weightGoal.targetWeight > weightGoal.currentWeight 
                            ? `+${(weightGoal.targetWeight - weightGoal.currentWeight).toFixed(1)} kg` 
                            : 'Maintain'}
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleWeightGoalSubmit}
                  className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
                >
                  Generate Personalized Recommendations
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="recommendations" className="space-y-6">
            {showRecommendations ? (
              <NutritionRecommendations 
                weightGoal={weightGoal}
                currentIntake={currentIntake}
              />
            ) : (
              <Card className="glass-morphism border-emerald-200/50">
                <CardContent className="p-12 text-center">
                  <div className="text-4xl mb-4">🎯</div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Set Your Goals First</h3>
                  <p className="text-slate-600 mb-6">
                    Go to the "Set Goals" tab to configure your weight and activity level, 
                    then return here for personalized recommendations.
                  </p>
                  <Button 
                    onClick={() => {
                      const goalsTab = document.querySelector('[data-state="inactive"][value="goals"]') as HTMLElement;
                      goalsTab?.click();
                    }}
                    className="bg-emerald-500 hover:bg-emerald-600"
                  >
                    Set Goals Now
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}