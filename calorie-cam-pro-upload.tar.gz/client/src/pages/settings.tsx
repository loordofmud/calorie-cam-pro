import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/theme-provider";
import { ApiStatus } from "@/components/api-status";
import { AndroidInstallGuide } from "@/components/android-install-guide";

export default function Settings() {
  const [location, setLocation] = useLocation();
  const [notifications, setNotifications] = useState(true);
  const [units, setUnits] = useState("metric");
  const [dailyCalorieGoal, setDailyCalorieGoal] = useState("2000");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Your preferences have been updated successfully."
    });
  };

  const handleExportData = () => {
    toast({
      title: "Data export started",
      description: "Your food diary data will be downloaded shortly."
    });
  };

  const handleClearData = () => {
    toast({
      title: "Data cleared",
      description: "All your food diary data has been removed.",
      variant: "destructive"
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-200/30 to-green-300/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-blue-200/20 to-emerald-200/20 rounded-full blur-3xl animate-float-delayed"></div>
      </div>

      {/* Header */}
      <header className="relative glass-morphism sticky top-0 z-40 border-b border-white/20 dark:border-slate-700/20">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button
                onClick={() => setLocation('/')}
                variant="ghost"
                size="sm"
                className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg hover:from-emerald-600 hover:to-emerald-700"
              >
                <span className="text-white text-xl">←</span>
              </Button>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
                  Settings
                </h1>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">Customize your experience</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-4xl mx-auto px-4 py-6 pb-20">
        <div className="space-y-6">
          {/* Profile Settings */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>👤</span>
                <span>Profile</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Nutrition Goals */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>🎯</span>
                <span>Nutrition Goals</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="calories">Daily Calorie Goal</Label>
                <Input
                  id="calories"
                  type="number"
                  value={dailyCalorieGoal}
                  onChange={(e) => setDailyCalorieGoal(e.target.value)}
                  placeholder="2000"
                />
              </div>
              <div>
                <Label htmlFor="units">Units</Label>
                <Select value={units} onValueChange={setUnits}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="metric">Metric (kg, cm)</SelectItem>
                    <SelectItem value="imperial">Imperial (lbs, ft)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* App Preferences */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>📱</span>
                <span>App Preferences</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications">Push Notifications</Label>
                  <p className="text-sm text-slate-600">Get reminders to log your meals</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="darkmode">Dark Mode</Label>
                  <p className="text-sm text-slate-600 dark:text-slate-300">Switch to dark theme</p>
                </div>
                <Switch
                  id="darkmode"
                  checked={theme === "dark"}
                  onCheckedChange={toggleTheme}
                />
              </div>
            </CardContent>
          </Card>

          {/* API Status */}
          <ApiStatus />

          {/* Data Management */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>💾</span>
                <span>Data Management</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleExportData}
                  variant="outline"
                  className="flex-1"
                >
                  📤 Export Data
                </Button>
                <Button
                  onClick={handleClearData}
                  variant="destructive"
                  className="flex-1"
                >
                  🗑️ Clear All Data
                </Button>
              </div>
              <p className="text-sm text-slate-600">
                Export your food diary data or clear all stored information
              </p>
            </CardContent>
          </Card>

          {/* App Installation */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>📱</span>
                <span>Install App</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col space-y-3">
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  Install Calorie Cam Pro on your device for the best experience
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <AndroidInstallGuide />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* About */}
          <Card className="glass-morphism border-emerald-200/50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span>ℹ️</span>
                <span>About</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-sm text-slate-600">
                  <strong>Calorie Cam Pro</strong> v1.0.0
                </p>
                <p className="text-sm text-slate-600">
                  AI-powered nutrition analysis for better health tracking
                </p>
                <p className="text-sm text-slate-600">
                  Built with love using modern web technologies
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white py-4 px-6 rounded-2xl font-semibold shadow-lg"
          >
            💾 Save Settings
          </Button>
        </div>
      </main>
    </div>
  );
}