import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { CameraInterface } from "@/components/camera-interface";
import { NutritionDisplay } from "@/components/nutrition-display";
import { AnalysisResults } from "@/components/analysis-results";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { MealSelector } from "@/components/meal-selector";
import { FoodDiarySummary } from "@/components/food-diary-summary";
import { useNutritionAnalysis } from "@/hooks/use-nutrition-analysis";
import { useFoodDiary } from "@/hooks/use-food-diary";
import { NutritionData } from "@shared/schema";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [location, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [analysisResults, setAnalysisResults] = useState<NutritionData | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showLoading, setShowLoading] = useState(true);
  const [mealType, setMealType] = useState("snack");
  const [notes, setNotes] = useState("");
  const [currentView, setCurrentView] = useState<'camera' | 'diary'>('camera');
  const { analyzeFood, isLoading, error } = useNutritionAnalysis();
  
  // For demo purposes, using userId = 1. In real app, this would come from auth
  const userId = 1;
  const today = new Date().toISOString().split('T')[0];
  const { diary, meals, isLoading: diaryLoading } = useFoodDiary(userId, today);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Hide loading screen after 2 seconds
    const timer = setTimeout(() => {
      setShowLoading(false);
    }, 2000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearTimeout(timer);
    };
  }, []);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setAnalysisResults(null);
  };

  const handleAnalyze = async () => {
    if (!selectedFile) return;

    try {
      // Create FormData with meal type and notes
      const formData = new FormData();
      formData.append('image', selectedFile);
      formData.append('userId', userId.toString());
      formData.append('mealType', mealType);
      if (notes) formData.append('notes', notes);

      const response = await fetch('/api/analyze-food', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Analysis failed');
      }

      const data = await response.json();
      setAnalysisResults(data.analysisResults);
      
      // Reset form but keep file for potential re-analysis
      setNotes("");
      
    } catch (err) {
      console.error('Analysis failed:', err);
      // Don't reset the file on error so user can retry
    }
  };

  if (showLoading) {
    return (
      <div className="loading-screen">
        <div className="text-6xl mb-4 animate-pulse">🥗</div>
        <div className="text-2xl font-bold mb-2">Calorie Cam Pro</div>
        <div className="text-sm opacity-90 mb-8">AI-Powered Food & Drink Analysis</div>
        <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 relative overflow-hidden">
      <PWAInstallPrompt />
      
      {/* Connection Status */}
      <div className={`fixed top-0 left-0 right-0 bg-red-500 text-white text-center py-3 z-50 offline-banner ${!isOnline ? 'show' : ''}`}>
        <span className="text-sm font-medium">🔴 No internet connection - Working offline</span>
      </div>

      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-emerald-200/30 to-green-300/30 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-blue-200/20 to-emerald-200/20 rounded-full blur-3xl animate-float-delayed"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-purple-200/20 to-pink-200/20 rounded-full blur-3xl animate-pulse-slow"></div>
      </div>

      {/* Header */}
      <header className="relative glass-morphism sticky top-0 z-40 border-b border-white/20 dark:border-slate-700/20">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <span className="text-white text-xl">🥗</span>
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
                  Calorie Cam Pro
                </h1>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">AI Food & Drink Analysis</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1 text-xs text-slate-600">
                <div className={`w-2 h-2 rounded-full animate-pulse ${isOnline ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                <span className="font-medium hidden sm:inline">{isOnline ? 'Online' : 'Offline'}</span>
              </div>
              <div className="flex items-center space-x-1 text-xs text-slate-600">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                <span className="font-medium hidden sm:inline">99.2%</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative max-w-4xl mx-auto px-4 py-6 pb-20">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center px-3 py-1 bg-gradient-to-r from-emerald-100 to-green-100 text-emerald-700 rounded-full text-sm font-semibold mb-4">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 animate-pulse"></span>
            Trusted by 50K+ Users
          </div>
          
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-4 leading-tight">
            Unlock Your Food & Drink's
            <span className="block bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
              Hidden Secrets
            </span>
          </h2>
          
          <p className="text-slate-600 mb-6 max-w-md mx-auto">
            Transform any food or drink photo into comprehensive nutritional insights with scientific precision
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <div className="flex items-center space-x-2 glass-morphism px-3 py-1 rounded-xl">
              <span className="text-emerald-500">⚡</span>
              <span className="text-xs font-medium text-slate-700">3s Analysis</span>
            </div>
            <div className="flex items-center space-x-2 glass-morphism px-3 py-1 rounded-xl">
              <span className="text-blue-500">🎯</span>
              <span className="text-xs font-medium text-slate-700">37+ Nutrients</span>
            </div>
            <div className="flex items-center space-x-2 glass-morphism px-3 py-1 rounded-xl">
              <span className="text-purple-500">🧠</span>
              <span className="text-xs font-medium text-slate-700">Deep Learning</span>
            </div>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center justify-center mb-8">
          <div className="glass-morphism rounded-2xl p-2 inline-flex">
            <Button
              variant={currentView === 'camera' ? 'default' : 'ghost'}
              onClick={() => setCurrentView('camera')}
              className="rounded-xl px-6 py-3"
            >
              📸 Camera
            </Button>
            <Button
              variant={currentView === 'diary' ? 'default' : 'ghost'}
              onClick={() => setCurrentView('diary')}
              className="rounded-xl px-6 py-3"
            >
              📊 Food Diary
            </Button>
          </div>
        </div>

        {/* Camera View */}
        {currentView === 'camera' && (
          <div className="space-y-6">
            {/* Meal Selector */}
            <MealSelector
              mealType={mealType}
              notes={notes}
              onMealTypeChange={setMealType}
              onNotesChange={setNotes}
            />

            {/* Camera Interface */}
            <CameraInterface 
              onFileSelect={handleFileSelect}
              onAnalyze={handleAnalyze}
              selectedFile={selectedFile}
              isAnalyzing={isLoading}
              isOnline={isOnline}
              error={error}
            />

            {/* Analysis Results */}
            {analysisResults && (
              <AnalysisResults 
                analysisResults={analysisResults}
                selectedFile={selectedFile}
              />
            )}

            {/* Nutrition Display */}
            {analysisResults && (
              <NutritionDisplay nutritionData={analysisResults} />
            )}
          </div>
        )}

        {/* Food Diary View */}
        {currentView === 'diary' && (
          <div className="space-y-6">
            {diary && meals ? (
              <FoodDiarySummary diaryData={{ diary, meals }} />
            ) : (
              <div className="text-center py-12">
                <div className="text-4xl mb-4">📝</div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No food or drinks logged today</h3>
                <p className="text-slate-600 mb-6">Start by taking a photo of your food or drink!</p>
                <Button 
                  onClick={() => setCurrentView('camera')}
                  className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
                >
                  📸 Take Photo
                </Button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 glass-morphism-dark border-t border-white/20 z-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-around py-3">
            <button 
              onClick={() => setCurrentView('camera')}
              className={`flex flex-col items-center space-y-1 p-2 touch-feedback ${
                currentView === 'camera' ? 'text-white' : 'text-white/70'
              }`}
            >
              <span className="text-xl">📸</span>
              <span className="text-xs font-medium">Camera</span>
            </button>
            <button 
              onClick={() => setCurrentView('diary')}
              className={`flex flex-col items-center space-y-1 p-2 touch-feedback ${
                currentView === 'diary' ? 'text-white' : 'text-white/70'
              }`}
            >
              <span className="text-xl">📊</span>
              <span className="text-xs font-medium">Diary</span>
            </button>
            <button 
              onClick={() => setLocation('/goals')}
              className="flex flex-col items-center space-y-1 p-2 touch-feedback text-white/70 hover:text-white"
            >
              <span className="text-xl">🎯</span>
              <span className="text-xs font-medium">Goals</span>
            </button>
            <button 
              onClick={() => setLocation('/settings')}
              className="flex flex-col items-center space-y-1 p-2 touch-feedback text-white/70 hover:text-white"
            >
              <span className="text-xl">⚙️</span>
              <span className="text-xs font-medium">Settings</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}
