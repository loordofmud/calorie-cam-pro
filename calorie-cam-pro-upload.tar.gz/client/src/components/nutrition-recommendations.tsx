import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface WeightGoal {
  currentWeight: number;
  targetWeight: number;
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active';
  targetDate?: string;
}

interface FoodRecommendation {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  portion: string;
  benefits: string[];
  category: 'protein' | 'carbs' | 'vegetables' | 'fruits' | 'dairy' | 'fats' | 'snacks';
  healthScore: number;
  icon: string;
}

interface NutritionRecommendations {
  dailyCalories: number;
  dailyProtein: number;
  dailyCarbs: number;
  dailyFat: number;
  recommendedFoods: FoodRecommendation[];
  mealPlan: {
    breakfast: FoodRecommendation[];
    lunch: FoodRecommendation[];
    dinner: FoodRecommendation[];
    snacks: FoodRecommendation[];
  };
  tips: string[];
}

interface NutritionRecommendationsProps {
  weightGoal: WeightGoal;
  currentIntake: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

export function NutritionRecommendations({ weightGoal, currentIntake }: NutritionRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<NutritionRecommendations | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const response = await fetch('/api/nutrition-recommendations', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ weightGoal, currentIntake }),
        });
        
        if (response.ok) {
          const data = await response.json();
          setRecommendations(data);
        }
      } catch (error) {
        console.error('Failed to fetch recommendations:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, [weightGoal, currentIntake]);

  if (loading) {
    return (
      <Card className="glass-morphism border-emerald-200/50">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
            <span className="ml-2 text-slate-600">Loading recommendations...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!recommendations) {
    return (
      <Card className="glass-morphism border-emerald-200/50">
        <CardContent className="p-6">
          <p className="text-slate-600">Unable to load recommendations. Please try again.</p>
        </CardContent>
      </Card>
    );
  }

  const calorieProgress = (currentIntake.calories / recommendations.dailyCalories) * 100;
  const proteinProgress = (currentIntake.protein / recommendations.dailyProtein) * 100;
  const carbsProgress = (currentIntake.carbs / recommendations.dailyCarbs) * 100;
  const fatProgress = (currentIntake.fat / recommendations.dailyFat) * 100;

  const goalType = weightGoal.targetWeight < weightGoal.currentWeight ? 'Weight Loss' : 
                   weightGoal.targetWeight > weightGoal.currentWeight ? 'Weight Gain' : 'Maintenance';

  return (
    <div className="space-y-6">
      {/* Goal Overview */}
      <Card className="glass-morphism border-emerald-200/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <span>🎯</span>
            <span>Your {goalType} Plan</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-600">{recommendations.dailyCalories}</div>
              <div className="text-sm text-slate-600">Daily Calories</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{recommendations.dailyProtein}g</div>
              <div className="text-sm text-slate-600">Protein</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{recommendations.dailyCarbs}g</div>
              <div className="text-sm text-slate-600">Carbs</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{recommendations.dailyFat}g</div>
              <div className="text-sm text-slate-600">Fat</div>
            </div>
          </div>
          
          {/* Progress Bars */}
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Calories</span>
                <span>{currentIntake.calories} / {recommendations.dailyCalories}</span>
              </div>
              <Progress value={Math.min(calorieProgress, 100)} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Protein</span>
                <span>{currentIntake.protein}g / {recommendations.dailyProtein}g</span>
              </div>
              <Progress value={Math.min(proteinProgress, 100)} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Carbs</span>
                <span>{currentIntake.carbs}g / {recommendations.dailyCarbs}g</span>
              </div>
              <Progress value={Math.min(carbsProgress, 100)} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Fat</span>
                <span>{currentIntake.fat}g / {recommendations.dailyFat}g</span>
              </div>
              <Progress value={Math.min(fatProgress, 100)} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations Tabs */}
      <Card className="glass-morphism border-emerald-200/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <span>🍽️</span>
            <span>Personalized Recommendations</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="foods" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="foods">Recommended Foods</TabsTrigger>
              <TabsTrigger value="meals">Meal Plan</TabsTrigger>
              <TabsTrigger value="tips">Tips</TabsTrigger>
            </TabsList>
            
            <TabsContent value="foods" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.recommendedFoods.map((food, index) => (
                  <div key={index} className="bg-white/50 rounded-xl p-4 border border-white/20">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{food.icon}</span>
                        <div>
                          <div className="font-semibold text-slate-900">{food.name}</div>
                          <div className="text-sm text-slate-600">{food.portion}</div>
                        </div>
                      </div>
                      <Badge variant="secondary">{food.healthScore}/10</Badge>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 text-xs text-slate-600 mb-3">
                      <div>
                        <div className="font-semibold text-slate-900">{food.calories}</div>
                        <div>cal</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.protein}g</div>
                        <div>protein</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.carbs}g</div>
                        <div>carbs</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.fat}g</div>
                        <div>fat</div>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {food.benefits.slice(0, 3).map((benefit, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {benefit}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="meals" className="space-y-4">
              <div className="space-y-6">
                {Object.entries(recommendations.mealPlan).map(([mealType, foods]) => (
                  <div key={mealType} className="bg-white/50 rounded-xl p-4 border border-white/20">
                    <h3 className="font-semibold text-slate-900 mb-3 capitalize">
                      {mealType === 'breakfast' ? '🍳' : 
                       mealType === 'lunch' ? '🥗' : 
                       mealType === 'dinner' ? '🍽️' : '🍿'} {mealType}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {foods.map((food, index) => (
                        <div key={index} className="flex items-center space-x-3 p-2 bg-white/30 rounded-lg">
                          <span className="text-xl">{food.icon}</span>
                          <div>
                            <div className="font-medium text-slate-900">{food.name}</div>
                            <div className="text-sm text-slate-600">{food.calories} cal • {food.portion}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="tips" className="space-y-4">
              <div className="space-y-3">
                {recommendations.tips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-white/50 rounded-lg">
                    <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-white text-sm">💡</span>
                    </div>
                    <div className="text-slate-700">{tip}</div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}