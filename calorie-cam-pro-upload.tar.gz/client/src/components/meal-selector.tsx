import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface MealSelectorProps {
  onMealTypeChange: (mealType: string) => void;
  onNotesChange: (notes: string) => void;
  mealType: string;
  notes: string;
}

export function MealSelector({ onMealTypeChange, onNotesChange, mealType, notes }: MealSelectorProps) {
  const mealTypes = [
    { value: "breakfast", label: "🍳 Breakfast", icon: "🍳" },
    { value: "lunch", label: "🥗 Lunch", icon: "🥗" },
    { value: "dinner", label: "🍽️ Dinner", icon: "🍽️" },
    { value: "snack", label: "🍿 Snack", icon: "🍿" },
    { value: "drink", label: "🥤 Drink", icon: "🥤" }
  ];

  return (
    <Card className="glass-morphism border-emerald-200/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold text-slate-900">🍽️ Meal & Drink Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium text-slate-700 mb-2 block">
            Type
          </label>
          <Select value={mealType} onValueChange={onMealTypeChange}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select meal or drink type" />
            </SelectTrigger>
            <SelectContent>
              {mealTypes.map((meal) => (
                <SelectItem key={meal.value} value={meal.value}>
                  {meal.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm font-medium text-slate-700 mb-2 block">
            Notes (Optional)
          </label>
          <Textarea
            value={notes}
            onChange={(e) => onNotesChange(e.target.value)}
            placeholder="Add any notes about this meal or drink..."
            className="min-h-[80px] resize-none"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {mealTypes.map((meal) => (
            <Button
              key={meal.value}
              variant={mealType === meal.value ? "default" : "outline"}
              size="sm"
              onClick={() => onMealTypeChange(meal.value)}
              className="text-xs"
            >
              {meal.icon} {meal.label.split(' ')[1]}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}