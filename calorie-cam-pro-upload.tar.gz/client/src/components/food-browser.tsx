import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

interface FoodItem {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  portion: string;
  benefits: string[];
  category: 'protein' | 'carbs' | 'vegetables' | 'fruits' | 'dairy' | 'fats' | 'snacks';
  healthScore: number;
  icon: string;
}

interface FoodBrowserProps {
  onAddFood?: (food: FoodItem) => void;
  showAddButton?: boolean;
}

export function FoodBrowser({ onAddFood, showAddButton = true }: FoodBrowserProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("name");

  const { data: foods = [], isLoading } = useQuery({
    queryKey: ['/api/food-database'],
  });

  const categories = [
    { value: "all", label: "All Foods", icon: "🍽️" },
    { value: "protein", label: "Proteins", icon: "🥩" },
    { value: "carbs", label: "Carbohydrates", icon: "🍞" },
    { value: "vegetables", label: "Vegetables", icon: "🥬" },
    { value: "fruits", label: "Fruits", icon: "🍎" },
    { value: "dairy", label: "Dairy", icon: "🥛" },
    { value: "fats", label: "Healthy Fats", icon: "🥑" },
    { value: "snacks", label: "Snacks", icon: "🥜" }
  ];

  const filteredFoods = foods
    .filter((food: FoodItem) => {
      const matchesSearch = food.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           food.benefits.some(benefit => benefit.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesCategory = selectedCategory === "all" || food.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a: FoodItem, b: FoodItem) => {
      switch (sortBy) {
        case "calories":
          return a.calories - b.calories;
        case "protein":
          return b.protein - a.protein;
        case "healthScore":
          return b.healthScore - a.healthScore;
        case "name":
        default:
          return a.name.localeCompare(b.name);
      }
    });

  const getCategoryCount = (category: string) => {
    if (category === "all") return foods.length;
    return foods.filter((food: FoodItem) => food.category === category).length;
  };

  if (isLoading) {
    return (
      <Card className="glass-morphism border-emerald-200/50">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
            <span className="ml-2 text-slate-600">Loading food database...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="glass-morphism border-emerald-200/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <span>🍽️</span>
            <span>Food Database</span>
            <Badge variant="secondary">{foods.length} foods</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Search foods or benefits..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.icon} {category.label} ({getCategoryCount(category.value)})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-[160px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="calories">Calories</SelectItem>
                <SelectItem value="protein">Protein</SelectItem>
                <SelectItem value="healthScore">Health Score</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="grid" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="grid">Grid View</TabsTrigger>
              <TabsTrigger value="list">List View</TabsTrigger>
            </TabsList>
            
            <TabsContent value="grid" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredFoods.map((food: FoodItem, index: number) => (
                  <div key={index} className="bg-white/50 rounded-xl p-4 border border-white/20 hover:shadow-lg transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{food.icon}</span>
                        <div>
                          <div className="font-semibold text-slate-900">{food.name}</div>
                          <div className="text-sm text-slate-600">{food.portion}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{food.healthScore}/10</Badge>
                        <Badge variant="outline" className="text-xs">
                          {food.category}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 mb-3">
                      <div>
                        <div className="font-semibold text-slate-900">{food.calories}</div>
                        <div>calories</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.protein}g</div>
                        <div>protein</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.carbs}g</div>
                        <div>carbs</div>
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{food.fat}g</div>
                        <div>fat</div>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {food.benefits.slice(0, 3).map((benefit, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {benefit}
                        </Badge>
                      ))}
                    </div>

                    {showAddButton && onAddFood && (
                      <Button
                        onClick={() => onAddFood(food)}
                        size="sm"
                        className="w-full bg-emerald-500 hover:bg-emerald-600"
                      >
                        Add to Meal Plan
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="list" className="space-y-2">
              <div className="space-y-2">
                {filteredFoods.map((food: FoodItem, index: number) => (
                  <div key={index} className="bg-white/50 rounded-lg p-3 border border-white/20 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{food.icon}</span>
                        <div>
                          <div className="font-medium text-slate-900">{food.name}</div>
                          <div className="text-sm text-slate-600">{food.portion}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm">
                        <div className="text-center">
                          <div className="font-semibold text-slate-900">{food.calories}</div>
                          <div className="text-slate-600">cal</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-slate-900">{food.protein}g</div>
                          <div className="text-slate-600">protein</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-slate-900">{food.carbs}g</div>
                          <div className="text-slate-600">carbs</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold text-slate-900">{food.fat}g</div>
                          <div className="text-slate-600">fat</div>
                        </div>
                        <Badge variant="secondary">{food.healthScore}/10</Badge>
                        {showAddButton && onAddFood && (
                          <Button
                            onClick={() => onAddFood(food)}
                            size="sm"
                            className="bg-emerald-500 hover:bg-emerald-600"
                          >
                            Add
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          {filteredFoods.length === 0 && (
            <div className="text-center py-12">
              <div className="text-4xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">No foods found</h3>
              <p className="text-slate-600">Try adjusting your search or filters</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}