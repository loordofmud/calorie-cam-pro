import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Smartphone, 
  Download, 
  Chrome, 
  Settings, 
  Camera, 
  Wifi, 
  Shield, 
  CheckCircle,
  AlertCircle,
  Info,
  Code,
  Zap
} from 'lucide-react';

export function AndroidInstallGuide() {
  const [selectedTab, setSelectedTab] = useState('pwa');

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <div className="text-center space-y-3">
        <h1 className="text-3xl font-bold">Install Calorie Cam Pro on Android</h1>
        <p className="text-muted-foreground">
          Get the full nutrition analysis app experience on your Android device
        </p>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pwa" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            PWA Install (Recommended)
          </TabsTrigger>
          <TabsTrigger value="apk" className="flex items-center gap-2">
            <Code className="h-4 w-4" />
            APK Build
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pwa" className="space-y-6">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Recommended:</strong> Install as PWA for automatic updates and easier installation
            </AlertDescription>
          </Alert>

          <div className="grid gap-4">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Chrome className="h-5 w-5 text-blue-600" />
                  <CardTitle className="text-lg">Step 1: Open in Chrome</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <ol className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">1</span>
                    <span>Open Chrome browser on your Android device</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">2</span>
                    <span>Visit: <code className="bg-muted px-2 py-1 rounded text-xs">your-app-domain.replit.app</code></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">3</span>
                    <span>Wait for the page to load completely</span>
                  </li>
                </ol>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-lg">Step 2: Install as App</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <ol className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">1</span>
                    <span>Tap the menu button (⋮) in Chrome</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">2</span>
                    <span>Select "Add to Home screen" or "Install app"</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">3</span>
                    <span>Tap "Install" when prompted</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium">4</span>
                    <span>App will be added to your home screen</span>
                  </li>
                </ol>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5 text-purple-600" />
                  <CardTitle className="text-lg">Step 3: Use Like Native App</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Launch from home screen</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Full-screen experience</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Camera access</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Offline features</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="apk" className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>For Developers:</strong> Building APK requires Android development tools
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Prerequisites</CardTitle>
                <CardDescription>Required tools and setup</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Required</Badge>
                    <span className="text-sm">Android Studio</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Required</Badge>
                    <span className="text-sm">Android SDK (API 24+)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Required</Badge>
                    <span className="text-sm">Java Development Kit (JDK) 17+</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Build Commands</CardTitle>
                <CardDescription>Step-by-step APK creation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-medium">1. Build Web App</h4>
                  <code className="block bg-muted p-2 rounded text-sm">npm run build</code>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">2. Sync with Capacitor</h4>
                  <code className="block bg-muted p-2 rounded text-sm">npx cap sync android</code>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">3. Build APK</h4>
                  <code className="block bg-muted p-2 rounded text-sm">cd android && ./gradlew assembleDebug</code>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">4. Find APK</h4>
                  <code className="block bg-muted p-2 rounded text-sm">android/app/build/outputs/apk/debug/app-debug.apk</code>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Build Script</CardTitle>
                <CardDescription>Automated build process</CardDescription>
              </CardHeader>
              <CardContent>
                <code className="block bg-muted p-2 rounded text-sm">./build-apk.sh</code>
                <p className="text-sm text-muted-foreground mt-2">
                  This script automates the entire build process and shows the APK location
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            App Features & Permissions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">Features</h4>
              <ul className="space-y-1 text-sm">
                <li className="flex items-center gap-2">
                  <Camera className="h-3 w-3" />
                  <span>Food & drink photo analysis</span>
                </li>
                <li className="flex items-center gap-2">
                  <Zap className="h-3 w-3" />
                  <span>AI nutrition analysis</span>
                </li>
                <li className="flex items-center gap-2">
                  <Smartphone className="h-3 w-3" />
                  <span>Offline food diary</span>
                </li>
                <li className="flex items-center gap-2">
                  <Settings className="h-3 w-3" />
                  <span>Dark mode support</span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Permissions</h4>
              <ul className="space-y-1 text-sm">
                <li className="flex items-center gap-2">
                  <Camera className="h-3 w-3" />
                  <span>Camera access</span>
                </li>
                <li className="flex items-center gap-2">
                  <Download className="h-3 w-3" />
                  <span>Storage access</span>
                </li>
                <li className="flex items-center gap-2">
                  <Wifi className="h-3 w-3" />
                  <span>Internet access</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Why Choose PWA?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <Zap className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <h4 className="font-medium mb-1">Instant Install</h4>
              <p className="text-sm text-muted-foreground">No APK download needed</p>
            </div>
            <div className="text-center">
              <Download className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <h4 className="font-medium mb-1">Auto Updates</h4>
              <p className="text-sm text-muted-foreground">Always latest version</p>
            </div>
            <div className="text-center">
              <Shield className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <h4 className="font-medium mb-1">Same Features</h4>
              <p className="text-sm text-muted-foreground">Full app functionality</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>Note:</strong> Both installation methods provide the same features and performance. 
          The PWA option is recommended for most users as it's easier to install and automatically updates.
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default AndroidInstallGuide;