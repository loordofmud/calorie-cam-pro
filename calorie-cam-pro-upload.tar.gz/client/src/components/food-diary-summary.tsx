import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FoodDiaryData } from "@/hooks/use-food-diary";

interface FoodDiarySummaryProps {
  diaryData: FoodDiaryData;
}

export function FoodDiarySummary({ diaryData }: FoodDiarySummaryProps) {
  const { diary, meals } = diaryData;
  
  const calorieProgress = diary.targetCalories > 0 ? (diary.totalCalories / diary.targetCalories) * 100 : 0;
  const remainingCalories = diary.targetCalories - diary.totalCalories;
  
  const getMealsByType = (type: string) => {
    return meals.filter(meal => meal.mealType === type);
  };

  const mealTypes = [
    { key: 'breakfast', label: 'Breakfast', icon: '🍳' },
    { key: 'lunch', label: 'Lunch', icon: '🥗' },
    { key: 'dinner', label: 'Dinner', icon: '🍽️' },
    { key: 'snack', label: 'Snacks', icon: '🍿' },
    { key: 'drink', label: 'Drinks', icon: '🥤' }
  ];

  const getProgressColor = (progress: number) => {
    if (progress <= 70) return 'bg-emerald-500';
    if (progress <= 100) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* Daily Summary */}
      <Card className="glass-morphism border-emerald-200/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold text-slate-900">
            📊 Today's Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Calorie Progress */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-slate-700">Daily Calories</span>
                <span className="text-sm font-semibold text-slate-900">
                  {diary.totalCalories} / {diary.targetCalories}
                </span>
              </div>
              <Progress 
                value={Math.min(calorieProgress, 100)} 
                className={`h-3 ${getProgressColor(calorieProgress)}`}
              />
              <div className="flex justify-between text-xs text-slate-600">
                <span>
                  {remainingCalories > 0 ? `${remainingCalories} remaining` : `${Math.abs(remainingCalories)} over`}
                </span>
                <span>{calorieProgress.toFixed(0)}%</span>
              </div>
            </div>

            {/* Macronutrients */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-lg font-bold text-blue-600">{diary.totalProtein}g</div>
                <div className="text-xs text-slate-600">Protein</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">{diary.totalCarbs}g</div>
                <div className="text-xs text-slate-600">Carbs</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-purple-600">{diary.totalFat}g</div>
                <div className="text-xs text-slate-600">Fat</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Meals by Type */}
      <Card className="glass-morphism border-emerald-200/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold text-slate-900">
            🍽️ Meals & Drinks Today
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mealTypes.map((mealType) => {
              const mealCount = getMealsByType(mealType.key).length;
              const mealCalories = getMealsByType(mealType.key).reduce(
                (sum, meal) => sum + (meal.analysisResults.calories || 0), 0
              );
              
              return (
                <div key={mealType.key} className="flex items-center justify-between p-3 bg-white/50 rounded-xl">
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">{mealType.icon}</span>
                    <div>
                      <div className="font-medium text-slate-900">{mealType.label}</div>
                      <div className="text-xs text-slate-600">
                        {mealCount} item{mealCount !== 1 ? 's' : ''}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-slate-900">{mealCalories} cal</div>
                    <Badge variant="secondary" className="text-xs">
                      {mealCount > 0 ? 'Logged' : 'Empty'}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}