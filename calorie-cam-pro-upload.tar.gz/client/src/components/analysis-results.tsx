import { NutritionData } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface AnalysisResultsProps {
  analysisResults: NutritionData;
  selectedFile: File | null;
}

export function AnalysisResults({ analysisResults, selectedFile }: AnalysisResultsProps) {
  const { toast } = useToast();

  const handleSave = () => {
    // For now, show a success message. In a full implementation,
    // this would save to the food diary database
    toast({
      title: "Analysis saved",
      description: "Your food analysis has been saved to your diary."
    });
  };

  const handleShare = async () => {
    const shareText = `I analyzed my food and found ${analysisResults.calories} calories with a ${analysisResults.healthScore}/10 health score!`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Food Analysis',
          text: shareText,
          url: window.location.href
        });
        toast({
          title: "Shared successfully",
          description: "Your food analysis has been shared."
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback for browsers without Web Share API
      try {
        await navigator.clipboard.writeText(shareText);
        toast({
          title: "Copied to clipboard",
          description: "Your food analysis has been copied to clipboard."
        });
      } catch (err) {
        toast({
          title: "Copy failed",
          description: "Unable to copy to clipboard. Please try again.",
          variant: "destructive"
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Health Insights */}
      <div className="glass-morphism rounded-3xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 pointer-events-none"></div>
        
        <div className="relative z-10">
          <h3 className="text-lg font-bold text-slate-900 mb-6">🧠 AI Health Insights</h3>
          
          <div className="space-y-4">
            {analysisResults.insights.map((insight, index) => (
              <div key={index} className="flex items-start space-x-3 bg-white/50 rounded-xl p-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  insight.type === 'positive' ? 'bg-emerald-500' :
                  insight.type === 'warning' ? 'bg-yellow-500' :
                  'bg-blue-500'
                }`}>
                  <span className="text-white text-sm">{insight.icon}</span>
                </div>
                <div>
                  <div className="font-semibold text-slate-900 mb-1">{insight.title}</div>
                  <div className="text-sm text-slate-600">{insight.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
          onClick={handleSave}
          className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white py-4 px-6 rounded-2xl font-semibold shadow-lg touch-feedback"
        >
          📱 Save to Food Diary
        </Button>
        <Button 
          onClick={handleShare}
          variant="outline"
          className="flex-1 bg-white/50 backdrop-blur-sm text-slate-900 py-4 px-6 rounded-2xl font-semibold border border-white/20 hover:bg-white/70 touch-feedback"
        >
          📤 Share Analysis
        </Button>
      </div>
    </div>
  );
}
