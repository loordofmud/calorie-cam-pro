import { NutritionData } from "@shared/schema";
import { Progress } from "@/components/ui/progress";

interface NutritionDisplayProps {
  nutritionData: NutritionData;
}

export function NutritionDisplay({ nutritionData }: NutritionDisplayProps) {
  const totalMacros = nutritionData.protein + nutritionData.carbs + nutritionData.fat;
  const proteinPercentage = (nutritionData.protein / totalMacros) * 100;
  const carbsPercentage = (nutritionData.carbs / totalMacros) * 100;
  const fatPercentage = (nutritionData.fat / totalMacros) * 100;

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-emerald-600';
    if (score >= 6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 8) return 'Excellent';
    if (score >= 6) return 'Good';
    return 'Fair';
  };

  return (
    <div className="space-y-6">
      {/* Calorie Summary and Nutrition Score */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Calorie Summary */}
        <div className="glass-morphism rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 pointer-events-none"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900">🔥 Calorie Analysis</h3>
              <div className="text-xs text-slate-600 font-medium">Per serving</div>
            </div>
            
            <div className="text-center mb-6">
              <div className="text-4xl font-black text-slate-900 mb-2">{nutritionData.calories}</div>
              <div className="text-sm text-slate-600">Total Calories</div>
            </div>

            {/* Calorie breakdown */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Protein</span>
                <span className="text-sm font-semibold text-slate-900">{nutritionData.protein}g ({proteinPercentage.toFixed(0)}%)</span>
              </div>
              <Progress value={proteinPercentage} className="h-2" />
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Carbs</span>
                <span className="text-sm font-semibold text-slate-900">{nutritionData.carbs}g ({carbsPercentage.toFixed(0)}%)</span>
              </div>
              <Progress value={carbsPercentage} className="h-2" />
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600">Fat</span>
                <span className="text-sm font-semibold text-slate-900">{nutritionData.fat}g ({fatPercentage.toFixed(0)}%)</span>
              </div>
              <Progress value={fatPercentage} className="h-2" />
            </div>
          </div>
        </div>

        {/* Nutrition Score */}
        <div className="glass-morphism rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 pointer-events-none"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-slate-900">📊 Nutrition Score</h3>
              <div className="text-xs text-slate-600 font-medium">Health rating</div>
            </div>
            
            <div className="flex items-center justify-center mb-6">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 42 42">
                  <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#e2e8f0" strokeWidth="3"/>
                  <circle 
                    cx="21" 
                    cy="21" 
                    r="15.915" 
                    fill="transparent" 
                    stroke="#10b981" 
                    strokeWidth="3" 
                    strokeDasharray={`${(nutritionData.healthScore / 10) * 100} ${100 - (nutritionData.healthScore / 10) * 100}`}
                    className="transition-all duration-700 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className={`text-2xl font-black ${getScoreColor(nutritionData.healthScore)}`}>
                      {nutritionData.healthScore.toFixed(1)}
                    </div>
                    <div className="text-xs text-slate-600">{getScoreLabel(nutritionData.healthScore)}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Food Items */}
            <div className="grid grid-cols-1 gap-2">
              {nutritionData.foodItems.slice(0, 2).map((item, index) => (
                <div key={index} className="bg-white/50 rounded-xl p-3 text-center">
                  <div className="text-sm font-semibold text-slate-900">{item.name}</div>
                  <div className="text-xs text-slate-600">{item.portion} • {(item.confidence * 100).toFixed(0)}% sure</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Nutrition */}
      <div className="glass-morphism rounded-3xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-500/10 pointer-events-none"></div>
        
        <div className="relative z-10">
          <h3 className="text-lg font-bold text-slate-900 mb-6">🧬 Detailed Nutrition</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">💪</div>
              <div className="text-sm font-semibold text-slate-900">Protein</div>
              <div className="text-lg font-bold text-emerald-600">{nutritionData.protein}g</div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">🍞</div>
              <div className="text-sm font-semibold text-slate-900">Carbs</div>
              <div className="text-lg font-bold text-blue-600">{nutritionData.carbs}g</div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">🥑</div>
              <div className="text-sm font-semibold text-slate-900">Fat</div>
              <div className="text-lg font-bold text-purple-600">{nutritionData.fat}g</div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">🧂</div>
              <div className="text-sm font-semibold text-slate-900">Sodium</div>
              <div className="text-lg font-bold text-red-600">{nutritionData.sodium}mg</div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">🍎</div>
              <div className="text-sm font-semibold text-slate-900">Fiber</div>
              <div className="text-lg font-bold text-green-600">{nutritionData.fiber}g</div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">🍯</div>
              <div className="text-sm font-semibold text-slate-900">Sugar</div>
              <div className="text-lg font-bold text-yellow-600">{nutritionData.sugar}g</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
