import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, Info } from "lucide-react";

interface ApiHealth {
  status: string;
  timestamp: string;
  openaiConfigured: boolean;
  logmealConfigured: boolean;
  primaryApi: string;
}

export function ApiStatus() {
  const { data: health, isLoading } = useQuery<ApiHealth>({
    queryKey: ['/api/health'],
    refetchInterval: 30000, // Check every 30 seconds
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5" />
            API Status
          </CardTitle>
          <CardDescription>Checking API configuration...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!health) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <XCircle className="h-5 w-5" />
            API Status
          </CardTitle>
          <CardDescription>Unable to check API status</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          API Status
        </CardTitle>
        <CardDescription>
          Current API configuration and status
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Primary Analysis API:</span>
          <Badge variant={health.primaryApi === 'none' ? 'destructive' : 'default'}>
            {health.primaryApi}
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm">LogMeal API:</span>
            <Badge variant={health.logmealConfigured ? 'default' : 'secondary'}>
              {health.logmealConfigured ? 'Configured' : 'Not configured'}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm">OpenAI API:</span>
            <Badge variant={health.openaiConfigured ? 'default' : 'secondary'}>
              {health.openaiConfigured ? 'Configured' : 'Not configured'}
            </Badge>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground">
          {health.logmealConfigured && (
            <p className="mb-2">
              🎯 LogMeal API provides specialized food recognition and detailed nutritional analysis.
            </p>
          )}
          {health.openaiConfigured && !health.logmealConfigured && (
            <p className="mb-2">
              🤖 OpenAI Vision API provides general food analysis capabilities.
            </p>
          )}
          <p>Last checked: {new Date(health.timestamp).toLocaleTimeString()}</p>
        </div>
      </CardContent>
    </Card>
  );
}