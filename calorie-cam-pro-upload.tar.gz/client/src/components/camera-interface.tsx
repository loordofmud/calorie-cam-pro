import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

interface CameraInterfaceProps {
  onFileSelect: (file: File) => void;
  onAnalyze: () => void;
  selectedFile: File | null;
  isAnalyzing: boolean;
  isOnline: boolean;
  error?: string | null;
}

export function CameraInterface({ 
  onFileSelect, 
  onAnalyze, 
  selectedFile, 
  isAnalyzing, 
  isOnline, 
  error 
}: CameraInterfaceProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const { toast } = useToast();

  // Cleanup preview URL on unmount
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select a valid image file.",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "File size must be less than 10MB.",
        variant: "destructive"
      });
      return;
    }

    // Clean up previous preview URL
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }

    onFileSelect(file);
    
    // Create new preview URL
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleCapture = async () => {
    if (!selectedFile) return;
    
    if (!isOnline) {
      toast({
        title: "No internet connection",
        description: "Please connect to the internet to analyze your food.",
        variant: "destructive"
      });
      return;
    }

    await onAnalyze();
  };

  const handleCameraCapture = async () => {
    if (isCapturing) return; // Prevent multiple captures
    
    setIsCapturing(true);
    
    // Try to access camera and take photo
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment', // Use back camera if available
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          }
        });
        
        // Create video element to capture frame
        const video = document.createElement('video');
        video.srcObject = stream;
        video.autoplay = true;
        video.playsInline = true;
        video.muted = true; // Prevent audio feedback
        
        // Wait for video to be ready
        await new Promise<void>((resolve, reject) => {
          const timeout = setTimeout(() => {
            reject(new Error('Video loading timeout'));
          }, 10000); // 10 second timeout for slower devices
          
          const checkVideoReady = () => {
            if (video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0) {
              clearTimeout(timeout);
              resolve();
            } else {
              setTimeout(checkVideoReady, 100); // Check every 100ms
            }
          };
          
          video.onloadedmetadata = () => {
            video.play().then(() => {
              // Give the video a moment to fully load
              setTimeout(checkVideoReady, 200);
            }).catch(reject);
          };
          
          video.onerror = () => {
            clearTimeout(timeout);
            reject(new Error('Video loading error'));
          };
        });
        
        // Capture the frame
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        
        if (ctx && video.videoWidth > 0 && video.videoHeight > 0) {
          ctx.drawImage(video, 0, 0);
          
          canvas.toBlob((blob) => {
            if (blob) {
              const file = new File([blob], 'camera-capture.jpg', { type: 'image/jpeg' });
              handleFileSelect(file);
              toast({
                title: "Photo captured",
                description: "Image ready for analysis!"
              });
            }
            // Clean up stream
            stream.getTracks().forEach(track => track.stop());
            setIsCapturing(false);
          }, 'image/jpeg', 0.9);
        } else {
          toast({
            title: "Camera error",
            description: "Unable to capture photo. Please try again.",
            variant: "destructive"
          });
          stream.getTracks().forEach(track => track.stop());
          setIsCapturing(false);
        }
      } catch (error) {
        console.error('Camera error:', error);
        toast({
          title: "Camera access denied",
          description: "Please allow camera access or upload a photo instead.",
          variant: "destructive"
        });
        // Fallback to file input
        fileInputRef.current?.click();
        setIsCapturing(false);
      }
    } else {
      toast({
        title: "Camera not supported",
        description: "Your device doesn't support camera access. Please upload a photo instead.",
        variant: "destructive"
      });
      fileInputRef.current?.click();
      setIsCapturing(false);
    }
  };

  const handleReset = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    
    // Clear the selected file
    onFileSelect(null as any);
    
    toast({
      title: "Reset complete",
      description: "Ready to scan a new food item."
    });
  };

  return (
    <div className="glass-morphism rounded-3xl p-6 mb-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-green-500/10 pointer-events-none"></div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-slate-900">📸 Food & Drink Scanner</h3>
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="font-medium">Ready to scan</span>
          </div>
        </div>

        {/* Camera Viewfinder */}
        <div className="relative">
          <div 
            className={`viewfinder aspect-square rounded-2xl mb-6 flex items-center justify-center overflow-hidden relative cursor-pointer border-2 border-dashed transition-all duration-300 ${
              dragActive 
                ? 'border-emerald-400 bg-emerald-50' 
                : selectedFile 
                  ? 'border-emerald-400 bg-emerald-50' 
                  : 'border-slate-300 bg-slate-200'
            }`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={handleClick}
          >
            {isAnalyzing && <div className="scan-line animate-scan"></div>}
            
            {previewUrl ? (
              <img 
                src={previewUrl} 
                alt="Food to analyze" 
                className="w-full h-full object-cover" 
              />
            ) : (
              <div className="text-center">
                <div className="w-20 h-20 mx-auto rounded-3xl flex items-center justify-center mb-4 bg-gradient-to-br from-slate-300 to-slate-400">
                  <span className="text-4xl text-slate-600">📷</span>
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-2">Upload Food or Drink Photo</h4>
                <p className="text-slate-600 text-sm">Drag & drop your food/drink photo or click to browse</p>
              </div>
            )}
            
            {/* Viewfinder overlay */}
            {selectedFile && (
              <div className="absolute inset-4 border-2 border-white/50 rounded-xl pointer-events-none">
                <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-emerald-400 rounded-tl-xl"></div>
                <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-emerald-400 rounded-tr-xl"></div>
                <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-emerald-400 rounded-bl-xl"></div>
                <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-emerald-400 rounded-br-xl"></div>
              </div>
            )}
            
            {/* Analysis indicator */}
            {isAnalyzing && (
              <div className="absolute top-4 right-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                <span className="animate-pulse">🔍 Analyzing...</span>
              </div>
            )}
          </div>

          {/* Progress Bar */}
          {isAnalyzing && (
            <div className="mb-6">
              <div className="flex justify-between text-sm text-slate-600 mb-2">
                <span>Analyzing nutrition...</span>
                <span>Processing</span>
              </div>
              <Progress value={undefined} className="h-3" />
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-red-600 text-sm font-medium">{error}</p>
            </div>
          )}

          {/* Camera Controls */}
          <div className="flex items-center justify-center space-x-6">
            <button 
              onClick={handleCameraCapture}
              disabled={isAnalyzing || isCapturing}
              className="w-12 h-12 bg-white/50 hover:bg-white/70 rounded-full flex items-center justify-center touch-feedback disabled:opacity-50"
            >
              <span className="text-xl">{isCapturing ? '⏳' : '📷'}</span>
            </button>
            <Button 
              onClick={handleCapture}
              disabled={!selectedFile || isAnalyzing || !isOnline}
              className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 rounded-full shadow-lg touch-feedback"
            >
              {isAnalyzing ? (
                <span className="text-white text-lg animate-spin">⟳</span>
              ) : (
                <span className="text-white text-2xl">📸</span>
              )}
            </Button>
            <button 
              onClick={handleReset}
              disabled={!selectedFile || isAnalyzing}
              className="w-12 h-12 bg-white/50 hover:bg-white/70 rounded-full flex items-center justify-center touch-feedback disabled:opacity-50"
            >
              <span className="text-xl">🔄</span>
            </button>
          </div>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              handleFileSelect(file);
            }
            // Reset input to allow selecting same file again
            if (e.target) {
              e.target.value = '';
            }
          }}
        />
      </div>
    </div>
  );
}
