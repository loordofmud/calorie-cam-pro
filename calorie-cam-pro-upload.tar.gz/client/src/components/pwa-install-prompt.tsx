import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      
      // Show prompt after 3 seconds if not dismissed
      const timer = setTimeout(() => {
        const dismissed = localStorage.getItem('pwa-install-dismissed');
        if (!dismissed) {
          setShowPrompt(true);
        }
      }, 3000);

      return () => clearTimeout(timer);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      
      if (choiceResult.outcome === 'accepted') {
        console.log('PWA installed');
      }
      
      setDeferredPrompt(null);
      setShowPrompt(false);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwa-install-dismissed', 'true');
  };

  if (!showPrompt) return null;

  return (
    <div className="install-prompt show">
      <div className="font-semibold mb-2">📱 Install Calorie Cam Pro</div>
      <div className="text-sm opacity-90 mb-4">Add to your home screen for quick access</div>
      <div className="flex space-x-2">
        <Button 
          onClick={handleInstall}
          className="bg-white text-emerald-600 hover:bg-white/90 px-4 py-2 rounded-xl font-semibold touch-feedback"
        >
          Install App
        </Button>
        <Button 
          onClick={handleDismiss}
          variant="outline"
          className="bg-white/20 text-white hover:bg-white/30 px-4 py-2 rounded-xl font-semibold border border-white/30 touch-feedback"
        >
          Later
        </Button>
      </div>
    </div>
  );
}
