import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { NutritionData } from "@shared/schema";

export function useNutritionAnalysis() {
  const [error, setError] = useState<string | null>(null);

  const analyzeFood = async (file: File): Promise<NutritionData> => {
    const formData = new FormData();
    formData.append('image', file);

    const response = await fetch('/api/analyze-food', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Analysis failed');
    }

    const data = await response.json();
    return data.analysisResults;
  };

  const mutation = useMutation({
    mutationFn: analyzeFood,
    onError: (error: Error) => {
      setError(error.message);
    },
    onSuccess: () => {
      setError(null);
    }
  });

  return {
    analyzeFood: mutation.mutateAsync,
    isLoading: mutation.isPending,
    error: error || (mutation.error?.message || null)
  };
}
