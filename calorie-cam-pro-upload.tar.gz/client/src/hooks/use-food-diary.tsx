import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export interface FoodDiaryData {
  diary: {
    userId: number;
    date: string;
    targetCalories: number;
    totalCalories: number;
    totalProtein: number;
    totalCarbs: number;
    totalFat: number;
  };
  meals: Array<{
    id: number;
    mealType: string;
    notes?: string;
    analysisResults: any;
    createdAt: string;
  }>;
}

export function useFoodDiary(userId: number, date: string) {
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ['food-diary', userId, date],
    queryFn: async () => {
      const response = await fetch(`/api/food-diary/${userId}/${date}`);
      if (!response.ok) {
        throw new Error('Failed to fetch food diary');
      }
      return response.json() as Promise<FoodDiaryData>;
    },
    enabled: !!userId && !!date
  });

  const updateTargetCalories = useMutation({
    mutationFn: async (targetCalories: number) => {
      return apiRequest({
        url: `/api/food-diary/${userId}/${date}`,
        method: 'PUT',
        body: { targetCalories }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['food-diary', userId, date] });
    }
  });

  const deleteFoodAnalysis = useMutation({
    mutationFn: async (analysisId: number) => {
      return apiRequest({
        url: `/api/food-analysis/${analysisId}`,
        method: 'DELETE'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['food-diary', userId, date] });
    }
  });

  return {
    diary: data?.diary,
    meals: data?.meals || [],
    isLoading,
    error,
    updateTargetCalories: updateTargetCalories.mutateAsync,
    deleteFoodAnalysis: deleteFoodAnalysis.mutateAsync,
    isUpdating: updateTargetCalories.isPending || deleteFoodAnalysis.isPending
  };
}