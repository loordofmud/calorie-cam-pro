export const registerServiceWorker = async () => {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered:', registration);
      return registration;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
      throw error;
    }
  }
  throw new Error('Service Worker not supported');
};

export const checkOnlineStatus = () => {
  return navigator.onLine;
};

export const addBeforeInstallPromptListener = (callback: (event: Event) => void) => {
  window.addEventListener('beforeinstallprompt', callback);
  
  return () => {
    window.removeEventListener('beforeinstallprompt', callback);
  };
};

export const requestNotificationPermission = async () => {
  if ('Notification' in window) {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

export const showNotification = (title: string, options?: NotificationOptions) => {
  if ('Notification' in window && Notification.permission === 'granted') {
    return new Notification(title, options);
  }
  return null;
};
