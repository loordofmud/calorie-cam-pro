package com.caloriecampro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
