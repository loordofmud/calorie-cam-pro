const fs = require('fs');

// Simple colored square icon as base64
const icon192 = "data:image/svg+xml,%3Csvg width='192' height='192' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='192' height='192' fill='%23059669'/%3E%3Ccircle cx='96' cy='96' r='60' fill='%23ffffff' opacity='0.3'/%3E%3Ctext x='96' y='110' font-family='Arial' font-size='36' fill='white' text-anchor='middle'%3E🍎%3C/text%3E%3C/svg%3E";
const icon512 = "data:image/svg+xml,%3Csvg width='512' height='512' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='512' height='512' fill='%23059669'/%3E%3Ccircle cx='256' cy='256' r='160' fill='%23ffffff' opacity='0.3'/%3E%3Ctext x='256' y='300' font-family='Arial' font-size='96' fill='white' text-anchor='middle'%3E🍎%3C/text%3E%3C/svg%3E";

// Create simple placeholder icons
fs.writeFileSync('icon-192.png', Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChAI9F8CZwQAAAABJRU5ErkJggg==', 'base64'));
fs.writeFileSync('icon-512.png', Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChAI9F8CZwQAAAABJRU5ErkJggg==', 'base64'));

console.log('Icon files created');
