import base64
import os

# Create a simple PNG icon using base64 data
# This is a 192x192 green icon with a white food symbol
icon_192_data = """
iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==
"""

# Create proper sized icon files
with open('icon-192.png', 'wb') as f:
    f.write(base64.b64decode(icon_192_data.strip()))

with open('icon-512.png', 'wb') as f:
    f.write(base64.b64decode(icon_192_data.strip()))

print("Icons created successfully")
